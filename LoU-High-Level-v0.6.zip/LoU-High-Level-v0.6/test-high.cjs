const assert=require('assert'),HighDuel=require('./high-engine.js');
const close=(a,b)=>assert(Math.abs(a-b)<1e-6,`${a} != ${b}`);
let g=new HighDuel({preset:'base',mode:'local'}),a=g.actor('akira'),r=g.actor('rikito');
assert.equal(g.base('akira').native,720);assert.equal(g.base('akira').spirit,1175);assert.equal(g.base('akira').aether,1895);assert.equal(g.base('rikito').aether,1882);
const no=new HighDuel({spirits:false,mode:'local'});assert.equal(no.base('akira').aether,720);assert.equal(no.base('rikito').aether,1000);assert(no.reason(no.actor('rikito'),no.d.moves.moondrip).includes('disabled'));
assert(g.reason(a,g.d.moves.substitute).includes('clone'));assert(g.reason(a,g.d.moves.festival).includes('familiarity'));
g.enter(a,'tgou');g.enter(a,'usr');g.enter(a,'gem');g.enter(a,'solar');g.enter(a,'dp');assert.equal(a.layers.length,5);const m=g.multipliers(a);close(m.p,1.35*1.35*1.2*1.08*1.08);
a.clones=2;g.enter(a,'esr1');assert.equal(a.clones,0);assert(!a.layers.includes('usr'));assert(!a.layers.includes('gem'));assert(g.reason(a,g.d.moves.clones).includes('incompatible'));assert(g.reason(a,g.d.moves.esr12).includes('Seventh'));
g.enter(a,'esr7');g.enter(a,'esr12');assert(a.layers.includes('esr12'));g.enter(a,'photo');assert.deepEqual(a.layers.sort(),['dp','photo','solar']);assert(g.reason(a,g.d.moves.tgou).includes('Release Photoreception'));
g=new HighDuel({preset:'peak',mode:'local',environment:'sealed'});a=g.actor('akira');r=g.actor('rikito');assert(!a.layers.includes('esr12'));a.aether=1;a.will=1;g.tick();assert.equal(a.layers.length,0);assert.equal(a.aether,0);
g=new HighDuel({preset:'peak',mode:'local'});a=g.actor('akira');a.hp=1;a.status.regen=40;g.tick();assert.equal(a.hp,0);assert(g.over,'strain must not revive through regeneration');
g=new HighDuel({preset:'war',mode:'local'});a=g.actor('akira');r=g.actor('rikito');r.will=.01;g.tick();assert(r.layers.every(k=>!g.d.forms[k].willTick));
// Moon Drip caps and once-per-match gate.
g=new HighDuel({preset:'base',mode:'local'});r=g.actor('rikito');r.focus=13;r.hp=500;r.aether=50;r.stamina=20;assert(g.commit('rikito','moondrip').ok);g.t=r.pending.at;g.resolve();assert(r.aether>800);assert(r.hp>800);r.ready=g.t;assert(g.reason(r,g.d.moves.moondrip).includes('already used'));
// Genuine pre-existing clone consumption; control costs and cancel window.
g=new HighDuel({preset:'base',mode:'local'});a=g.actor('akira');a.clones=2;a.focus=14;assert(g.commit('akira','substitute').ok);assert.equal(a.clones,1);const spent=a.aether;assert(g.cancel('akira').ok);assert.equal(a.aether,spent);assert.equal(a.ready,6);assert(g.active(a,'guard'));assert(!g.cancel('akira').ok);
// Sealing interrupts pending Arts, not physical commitments.
g=new HighDuel({preset:'base',mode:'local'});a=g.actor('akira');r=g.actor('rikito');a.focus=14;a.familiarity=2;r.focus=13;g.commit('akira','festival');g.commit('rikito','ruination');g.t=a.pending.at;g.resolve();assert(!r.pending);assert(g.active(r,'sealed'));r.ready=g.t;assert(g.reason(r,g.d.moves.cannon).includes('suppressed'));assert.equal(g.reason(r,g.d.moves.jab),'');
// Reflection only reacts once and does not reflect an area hit.
g=new HighDuel({preset:'base',mode:'local'});a=g.actor('akira');r=g.actor('rikito');r.status.reflect=40;g.commit('akira','star');g.t=a.pending.at;g.resolve();assert(a.hp<g.base('akira').hp);assert(!g.active(r,'reflect'));
// Both simultaneous lethal attacks land.
g=new HighDuel({preset:'base',mode:'local'});a=g.actor('akira');r=g.actor('rikito');a.hp=r.hp=1;g.commit('akira','jab');g.commit('rikito','jab');a.pending.at=r.pending.at=5;g.t=5;g.resolve();assert(g.over);assert.equal(a.hp,0);assert.equal(r.hp,0);
// Seeded full matches using each side's deterministic chooser as a diagnostic bot.
for(const preset of ['base','war','peak'])for(const player of ['akira','rikito']){g=new HighDuel({preset,player});let steps=0;while(!g.over&&steps++<2500){const w=g.decision();if(w){const key=g.chooseAI(w);assert(g.submit(w.id,key).ok);}else g.next();for(const x of g.actors){const cap=g.base(x.id);for(const key of ['hp','aether','stamina','focus','will'])assert(Number.isFinite(x[key])&&x[key]>=0&&x[key]<=cap[key]+1e-6,key);const slots=x.layers.map(k=>g.d.forms[k].slot);assert.equal(new Set(slots).size,slots.length);}}assert(g.over,'fight did not finish');const frozen=JSON.stringify(g.history[0]);g.actor('akira').aether=0;assert.equal(JSON.stringify(g.history[0]),frozen);console.log(preset,player,'events',steps,'ticks',g.t);}
console.log('PASS: Spirit accounting, compatibility, depletion, Will collapse, healing, cancel, seal, reflection, simultaneous KOs, six full matches and immutable history.');
