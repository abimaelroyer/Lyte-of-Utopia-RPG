# Lyte of Utopia — High-level combat v0.6

An offline, single-computer feature test of recovered adult Akira and Rikito using late Arc IV kits. Read the build reference for canon boundaries and every proposed formula. This is a separate branch from the Arc I prototype, not an overwrite.

## Play

This release streamlines the UI: all resources use bars, total form modifiers stay visible, and full history lives in the History tab. Expand Forms & effects or Detailed causes for source-level detail. See `RELEASE-NOTES-v0.6.md` for the aggregation rules.

Open `index.html` in a modern browser. No installation, web server, account or network connection is required. Send the HTML alone to a tester, or send this ZIP for the source and sprites as well.

1. Start with the default War stack. Pick a category, select an action, read its costs and timing, then Commit.
2. Use Next event to advance manually, or change Playback to Auto. Auto pauses at the next player decision; browsing menus costs no game time.
3. Inspect the opponent's committed intent and compare startup against its impact tick. Guard, an evasive action, a cancel or an interruption has to fit the timeline.
4. Open Match setup and restart to change characters, presets, Spirit contributions, environment or opponent control.
5. Use Base to pay for and construct a stack yourself. Use Peak to stress-test maximum output and upkeep. Local control of both is useful for deliberate interaction tests, not hidden simultaneous PvP.
6. Open any recorded event to replay its snapshot. Replay is view-only; it cannot alter the live match. Restart clears the in-memory history.

There is no campaign save, online play or persistent character progression in this build. Advanced sprites and balance are provisional.

## Useful test routes

- Akira: Astra Eidolon Array → Astral Substitution; signature reading → Dragon Festival; compare Utopic/GEM with Exponential 1 → 7 → 12; use regeneration to test sustained strain; release that route for Photoreception, Supernova and the explicitly sacrificial Sunburst.
- Rikito: build the Demon/Soul/Force/Cloak/Infuscate stack; alternate Deep Crash or Black Lightning with expensive finishers; prepare Midnight + Archaic → Ruination Cannon; test Lunar Reflection and the once-per-spar Moon Drip.
- Both: pressure the opponent's Will, use Ego brace/Recenter, cancel a startup, compare Spirit-enabled/disabled and sunlit/sealed matches. Keep track of unused resources when the match ends.

## Files for Ab

| File | Role |
| --- | --- |
| `index.html` | Self-contained playable distribution; sprites and code embedded. |
| `combat-fragment.html` | Same game as an embeddable fragment. |
| `high-data.js` | Authoritative editable character, move, form and preset definitions. |
| `high-engine.js` | Tick engine, legality, resources, damage, AI and immutable recorded snapshots; independent of the DOM. |
| `high-view.js` | Groups structured history resources into readable totals. |
| `high-ui.js` | Menus, profiles, previews, playback and event display. |
| `high-lab.html`, `high-lab.css` | Scoped markup and styles. |
| `build-high.cjs` | Rebuilds both HTML outputs using local files and embedded PNGs. |
| `balance-data.json` | Release snapshot of the data definitions; not dynamically loaded by the game. |
| `assets/` | Six four-frame strips, 24 individual PNG frames and an anchor/size manifest. |
| `LoU-High-Level-Build-Reference-v0.6.md` | Current formulas, costs, form compatibility, source map, limits and test notes. |
| `RELEASE-NOTES-v0.6.md` | This release's implemented changes and unresolved work. |
| `test-high*.cjs` | Engine, edge-case and simulated-DOM tests. |

## Edit and verify

From this folder, with Node.js available:

```sh
node build-high.cjs
node test-high.cjs
node test-high-edge.cjs
node test-high-ui.cjs
node test-high-summary.cjs
```

There are no npm dependencies for the game, build or these tests. Rebuild after editing source; do not edit only the bundled HTML if you want changes to survive a rebuild. Update the reference/changelog whenever behavior or balance values change. `balance-data.json` is refreshed automatically by the build script from `high-data.js`.

Engine entry point: `new HighDuel({player:'akira', mode:'ai', preset:'war', spirits:true, environment:'sun'})`. In Node, `require('./high-engine.js')` returns the engine class. Use `decision()`, `available(actor)`, `terms(actor, move)`, `reason(actor, move)`, `submit(actorId, moveId)`, `next()` and `snapshot()` for an adapter. The UI currently provides a much smaller experience than a full game client.

The tests check logic and simulated DOM interactions. They do not launch a real browser, verify its rendered layout or establish competitive balance. Test the intended browser and viewport before integrating.

## Sprite handoff

Frame cells are 128 × 144 px; strips are 512 × 144 px with four horizontal frames. Use nearest-neighbor sampling and the anchor in `assets/manifest.json`. The UI enlarges cells without smoothing. Guard is reused for a quiet profile loop; physical attacks share strike poses and energy techniques share cast poses. Form effects are simplified code-drawn accents, not complete transformed character art.

The adult atlas was generated this release from the supplied character references, then cropped, chroma-keyed and aligned into strips. The portrait adaptations and resulting frames remain provisional. No extracted novel text or original portrait is included in this handoff pack.

## Scope and provenance

Canon sources: the supplied `Arc4_Full_Arc_Merged.docx` and `LoU_Miscellaneous_Compiled.docx`, especially the late Arc IV Cold World/Acier sequence and Moves notes. The build reference identifies the important passages and uncertain inclusions.

Akira's Spirit of Utopia and Helios, and Rikito's Lunario, contribute to one shared aether pool. Rikito's completed Utopic core is a distinct contribution, not another bound Spirit of Utopia. Every reserve proxy, numeric perk, stat, cost, multiplier and timing is a test value. Experimental Ego actions are labeled and are not newly asserted named canon Arts.

Akira's end-of-arc sacrificial outcome and injuries are not used as starting conditions. Post-death Primordial/Omni abilities, Akito fusion and later arcs are excluded. A maxed-kit test means unlocked options, not invulnerability or unlimited resources.
