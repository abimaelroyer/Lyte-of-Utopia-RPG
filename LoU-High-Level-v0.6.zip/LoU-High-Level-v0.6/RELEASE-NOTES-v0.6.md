# LoU high-level combat lab — v0.6

## Streamlined combat screen

- Each fighter's Health bar leads the panel. Aether, Focus, Stamina and Will sit immediately underneath in a compact two-column group. Every meter includes current/maximum numbers and accessible progress values.
- The physical/aether ATK, SPD and DEF table always appears, including in Base. It shows the multiplicative product of all current form and blessing layers, with 1× representing no form modifier. Character stats and conditional Art effects are separate; this is not an absolute damage or speed comparison between characters.
- One Form upkeep line shows the sum of all form-layer Aether and Will rates. Resource types remain separate units; they are never added into a misleading single currency.
- Forms & effects holds individual layers, drop controls, boon/flaw rates, sustained-Art upkeep, signature progress and temporary effects. Detail sections preserve their open/closed choices when actions rerender the combat screen.
- Timeline comparison and Latest event are expandable. Full event history has its own tab, so previous events no longer lengthen the combat screen.

## Summarized history

History lists the newest event first. Each event presents combat notices plus compact resource groups for each character:

| Group | Contains |
| --- | --- |
| Form upkeep | Combined actual Aether and Will spent across all active form layers. |
| Boons | Combined actual regeneration and recovery from forms, Spirits and sustained healing. |
| Flaws | Actual harmful continuous form effects, including Exponential strain. |
| Sustained Arts | Ongoing Art costs, separate from form upkeep. |
| Passive gain | Actual Flux-based Focus gain. The full cause records whether shaken reduced it. |
| Named actions | Costs or effects grouped by their named cause. Direct attack damage keeps its attack name. |

These are totals over the recorded event interval, not per-tick rates. The fighter panels show rates. Totals use actual post-cap changes: full health does not produce fictional healing entries. Separate resource types and positive/negative changes remain visible instead of being netted together.

Detailed causes retains every original message and named source. Replay still uses the recorded snapshot and never changes the live combat state. Recorded replay resource values also use bars with numbers.

## Implementation / handoff

- `high-engine.js` adds structured `resources` and narrative `notes` to each history entry. Original `messages` are retained. `change()` accepts an optional resource group; gameplay calculations and action rules are unchanged.
- `high-view.js` owns presentation aggregation independently of the engine. New forms should label recurring changes as `formUpkeep`, `boon` or `flaw`; ongoing Art costs use `artUpkeep`. Ordinary actions default to their named cause.
- `build-high.cjs` builds from its own folder, embeds the existing sprites and refreshes `balance-data.json` from the authoritative data file.
- The v0.5 release is retained separately for comparison. No new abilities, sprite designs, costs, multipliers, balance adjustments or canon interpretations are introduced here.

## Validation

Engine and edge-case tests continue to pass with the same six full-match event/tick counts as v0.5. Added tests verify grouped upkeep, boon/flaw separation, resource reconciliation, full-pool caps, retained source messages, ten live resource bars, History navigation, replay and all twelve base form-ratio values.

The UI checks use a simulated DOM. A real browser was unavailable in this environment, so rendered layout and animation still need human testing, especially on narrow screens.

## Changelog

### v0.6 — Interface and event summaries

Added the resource-bar group, persistent total form-ratio table, combined upkeep display, dedicated History tab, structured event categories and expandable detailed causes. Moved supporting information behind disclosures. Preserved the v0.5 gameplay, source-based builds, animation assets and recorded replay behavior.

### v0.5 — Adult Arc IV feature test

Introduced adult Akira/Rikito kits, Spirit contributions to a shared aether pool, experimental Ego/Will interactions, compatible form stacks, Base/War/Peak presets, manual/local or AI play, signature and clone interactions, counters, recovery and high-level finishers. Provisional numerical balance and shared advanced animation poses remain unresolved.
