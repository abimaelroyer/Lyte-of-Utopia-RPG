const assert=require('assert'),HighDuel=require('./high-engine.js'),View=require('./high-view.js');
const g=new HighDuel({preset:'war',mode:'local'}),a=g.actor('akira'),r=g.actor('rikito');
a.hp-=100;r.hp-=100;g.capture('Prepared');const before=g.snapshot();
for(let i=0;i<3;i++)g.tick();const e=g.capture('Tick interval'),groups=View.summarize(e,g.d);
const upkeep=groups.filter(x=>x.group==='formUpkeep');assert.equal(upkeep.length,2,'One upkeep group per character');
assert(Math.abs(upkeep.find(x=>x.id==='akira').events.filter(e=>e.key==='aether').reduce((s,e)=>s+e.delta,0)+12.6)<1e-8);
assert(upkeep.every(x=>!x.text.includes('Divine')&&!x.text.includes('Golden')),'No individual forms in upkeep summary');
assert.equal(groups.filter(x=>x.group==='boon').length,2,'All positive form/Spirit effects grouped per actor');
assert(e.messages.some(x=>x.includes('Golden Energy Mode')),'Raw causes retained');
for(const w of g.actors)for(const key of ['hp','aether','focus','stamina','will']){
 const actual=w[key]-before.actors.find(x=>x.id===w.id)[key],recorded=e.resources.filter(x=>x.id===w.id&&x.key===key).reduce((sum,x)=>sum+x.delta,0);
 assert(Math.abs(actual-recorded)<1e-7,w.id+' '+key+' does not reconcile');
}
const peak=new HighDuel({preset:'peak',mode:'local'});peak.actor('akira').hp-=100;peak.tick();const p=peak.capture('Strain');
assert.equal(View.summarize(p,peak.d).filter(x=>x.group==='flaw').length,1);
assert(View.summarize(p,peak.d).some(x=>x.group==='boon'&&x.id==='akira'));
const capped=new HighDuel({preset:'base',mode:'local'});capped.tick();const c=capped.capture('At cap');assert(!c.resources.some(x=>x.key==='hp'),'No fictional recovery at full HP');
assert.equal(View.amounts([{key:'hp',delta:2},{key:'hp',delta:-1}]),'+2 HP · −1 HP','Do not hide losses through netting');
const old=JSON.stringify(e);g.tick();assert.equal(JSON.stringify(e),old,'History snapshots remain immutable');
console.log('PASS: grouped upkeep/boons/flaws, precise resource reconciliation, caps, sign separation and retained raw causes.');
