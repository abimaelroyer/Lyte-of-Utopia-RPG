const assert=require('assert'),Game=require('./high-engine.js');
function lab(){return new Game({preset:'base',mode:'local'});}
let g=lab(),a=g.actor('akira'),r=g.actor('rikito');
// Shaken really halves passive Focus, then expires.
a.focus=0;a.status.shaken=4;g.tick();assert(Math.abs(a.focus-g.base('akira').passive/2)<1e-9);g.t=4;g.expire();assert(!g.active(a,'shaken'));
// Late defensive effect on the same tick protects either side symmetrically.
for(const attacker of ['akira','rikito']){g=lab();a=g.actor(attacker);r=g.other(a);g.commit(a.id,'heavy');g.commit(r.id,'guard');a.pending.at=r.pending.at=5;g.t=5;g.resolve();const cap=g.base(r.id).hp;const expected=Math.round(g.terms(a,g.d.moves.heavy).raw*100/(100+g.base(r.id).physical)*.4);assert.equal(cap-r.hp,expected);}
// Buff consumption cannot be duplicated by replay or by later attacks.
g=lab();r=g.actor('rikito');r.focus=13;r.status.midnight=60;r.status.archaic=60;g.commit('rikito','ruination');assert.equal(r.pending.bonus,1.3*1.35);assert(!g.active(r,'midnight'));assert(!g.active(r,'archaic'));
// Sealed physical-damage Arts still count as Arts; ordinary physical strikes remain legal.
g=lab();a=g.actor('akira');a.status.sealed=20;assert(g.reason(a,g.d.moves.godbreaker).includes('suppressed'));assert(g.reason(a,g.d.moves.shift).includes('suppressed'));assert.equal(g.reason(a,g.d.moves.jab),'');
// Sacrificial move never becomes a free win button.
g=lab();a=g.actor('akira');r=g.actor('rikito');g.enter(a,'photo');a.focus=14;r.hp=9999;g.commit('akira','sunburst');g.t=a.pending.at;g.resolve();assert.equal(a.hp,0);assert.equal(a.aether,0);assert(g.over);
// Empty pools do not become negative; dead actors never recover via the Spirit perk.
g=lab();a=g.actor('akira');a.hp=0;a.aether=0;g.tick();assert.equal(a.hp,0);assert.equal(a.aether,0);
// Resource changes in snapshots reconcile with initial values (before restart).
g=new Game({preset:'war'});for(let i=0;i<20&&!g.over;i++){const w=g.decision();if(w)g.submit(w.id,g.chooseAI(w));else g.next();}assert(g.history.some(e=>e.messages.some(m=>m.includes('upkeep'))));assert(g.history.some(e=>e.messages.some(m=>m.includes('commitment'))));
console.log('PASS: shaken effect, symmetric same-tick Guard, single-use buff consumption, physical Art sealing, sacrificial Sunburst and no resurrection.');
