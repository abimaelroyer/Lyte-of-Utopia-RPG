const fs=require('fs'),vm=require('vm'),assert=require('assert');
class Element{constructor(tag='div'){this.tagName=tag;this.children=[];this.style={};this.dataset={};this.attributes={};this.cache={};this.textContent='';this.hidden=false;this.value='';this.classList={add:(...classes)=>this.className=(this.className||'')+' '+classes.join(' ')};}append(...children){this.children.push(...children);}replaceChildren(...children){this.children=children;}setAttribute(k,v){this.attributes[k]=v;}querySelector(s){return this.cache[s]??=new Element();}querySelectorAll(){return [];}}
const root=new Element(),pages=['combat','akira','rikito','rules','history'].map(page=>{const e=new Element('button');e.dataset.page=page;return e;});
const settings=Object.entries({player:'akira',mode:'ai',preset:'war',spirits:'true',environment:'sun'}).map(([key,value])=>{const e=new Element('select');e.dataset.setting=key;e.value=value;return e;});root.querySelectorAll=s=>s==='[data-page]'?pages:s==='[data-setting]'?settings:[];
const doc={getElementById:()=>root,createElement:tag=>new Element(tag)};
const fragment=fs.existsSync('combat-fragment.html')?'combat-fragment.html':'/workspace/lou-high-level.html';
const html=fs.readFileSync(fragment,'utf8'),script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const ctx={document:doc,setTimeout,window:{matchMedia:()=>({matches:true})}};vm.createContext(ctx);vm.runInContext(script,ctx);
assert.equal(root.querySelector('.fighters').children.length,2);assert.equal(root.querySelector('.arena').children.length,2);assert.equal(root.querySelector('.categories').children.length,6);
pages[1].onclick();assert(root.querySelector('.profile-page').children.length);pages[2].onclick();assert(root.querySelector('.profile-page').children.length);pages[0].onclick();
root.querySelector('.categories').children.find(e=>e.textContent==='Forms').onclick();assert(root.querySelector('.moves').children.length>=8);
root.querySelector('.categories').children.find(e=>e.textContent==='Attacks').onclick();root.querySelector('.commit').onclick();assert(!root.querySelector('.next').disabled);
let steps=0;while(!root.querySelector('.next').disabled&&steps++<30)root.querySelector('.next').onclick();assert(steps<30);assert(root.querySelector('.history').children.length>1);
function descendants(e){return [e,...e.children.flatMap(descendants)];}
pages[4].onclick();assert(!root.querySelector('.history-page').hidden);assert(root.querySelector('.combat-page').hidden);
descendants(root.querySelector('.history').children[0]).find(e=>e.tagName==='button'&&e.textContent==='Replay recorded event').onclick();assert(!root.querySelector('.replay').hidden);root.querySelector('.close-replay').onclick();assert(root.querySelector('.replay').hidden);
pages[0].onclick();assert(root.querySelector('.history-page').hidden);
assert.equal(descendants(root.querySelector('.fighters')).filter(e=>e.attributes.role==='progressbar').length,10);
assert.equal(descendants(root.querySelector('.fighters')).filter(e=>e.className==='ratios').length,2);
assert(root.querySelector('.latest-body').children.length);
settings.find(e=>e.dataset.setting==='preset').value='base';root.querySelector('.restart').onclick();
const ratioCells=descendants(root.querySelector('.fighters')).filter(e=>e.tagName==='td'&&e.textContent==='1×');assert.equal(ratioCells.length,12,'Base retains all physical/aether ATK SPD DEF ratios');
settings.find(e=>e.dataset.setting==='player').value='rikito';settings.find(e=>e.dataset.setting==='mode').value='local';root.querySelector('.restart').onclick();assert(root.querySelector('.commit').textContent.includes('Rikito'));
assert.equal((html.match(/background-image:url\(data:image\/png/g)||[]).length,6);assert(!html.includes('fetch('));
console.log('PASS: UI wiring, ten resource bars, base/form ratios, History tab, summaries, profiles, categories, actions, replay and reset. Not a browser rendering test.');
