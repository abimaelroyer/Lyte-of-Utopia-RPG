/* Presentation-only summaries. Values remain separate by resource and sign. */
const HighView=(()=>{
 const names={hp:'HP',aether:'Aether',stamina:'Stamina',focus:'Focus',will:'Will'};
 const labels={formUpkeep:'Form upkeep',boon:'Boons',flaw:'Flaws',artUpkeep:'Sustained Arts',passive:'Passive gain'};
 const fmt=n=>Number(n.toFixed(2)).toString();
 function amounts(events){const totals=new Map();for(const e of events){const k=e.key+'|'+(e.delta<0?'-':'+');const x=totals.get(k)||{key:e.key,delta:0};x.delta+=e.delta;totals.set(k,x);}return [...totals.values()].filter(x=>Math.abs(x.delta)>1e-8).map(x=>(x.delta>0?'+':'−')+fmt(Math.abs(x.delta))+' '+(names[x.key]||x.key)).join(' · ');}
 function summarize(entry,data){const groups=new Map();for(const e of entry.resources||[]){const group=e.group||'action',key=e.id+'|'+group+(group==='action'?'|'+e.reason:'');const row=groups.get(key)||{id:e.id,group,title:labels[group]||e.reason,events:[]};row.events.push(e);groups.set(key,row);}return [...groups.values()].map(row=>({...row,text:data.people[row.id].name+' · '+row.title+' · '+amounts(row.events)}));}
 return {names,fmt,amounts,summarize};
})();
if(typeof module!=='undefined')module.exports=HighView;
