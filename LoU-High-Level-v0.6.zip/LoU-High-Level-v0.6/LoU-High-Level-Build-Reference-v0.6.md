# Lyte of Utopia High Level Combat Build Reference

Version 0.6 • Arc IV sandbox branch • 13 September 2026

## Interface update

Version 0.6 preserves the preceding high-level gameplay rules while reorganizing the resource panels and history. `RELEASE-NOTES-v0.6.md` explains grouped event totals, the persistent form ATK/SPD/DEF ratios and expandable detailed causes. The full history is on the History tab. Panel upkeep values are rates per tick; recorded event values are actual totals over the interval.

## Purpose and canon boundary

This is a recovered adult Akira–Rikito feature test using abilities available or listed by the end of Arc IV. It does not reproduce their injuries, exhaustion or deaths at the ending. No Primordial Akira, Second Genesis after revival, Omni Seed, later omnipotent techniques or Akito fusion is included.

“Maxed” means a late-Arc-IV unlocked kit with deliberately differentiated high stats—not every stat set to a common ceiling, not a canon level, and not a conversion of Yield. The canonical gap between Akira’s later peaks and Rikito’s is compressed to make a useful duel. All HP, pool capacities, costs, timings, cooldowns, damage values and numeric perks are experimental game rules.

The earlier Arc I v0.4 test remains a separate build. This document is the current record for the new v0.6 branch; it does not retroactively change the Arc I formulas or abilities.

## Quick start

Open the downloadable HTML or the package’s index.html in a browser. Choose Akira or Rikito in Match setup. Tactical AI shows committed enemy intent; Local control of both allows alternating control on one computer, not online multiplayer or hidden simultaneous input.

Start with War stack to sample mature play, Base to build transformations through paid actions, or Peak to stress-test maximum output. Preset layers are activated free at setup and start with recovered resources. Activating them in the fight pays the listed costs. A sealed arena disables solar recovery/absorption and Exponential setup; Akira’s Peak preset falls back to War layers there.

Select an action to inspect it, then Commit. Next event progresses to an impact, expiry, depletion or readiness event; Auto plays to the next decision. Recorded replay only displays snapshots and effects. It never spends resources, rewinds the live battle or permits alternate historical choices. Restart clears the in-memory history. There is no campaign save.

## Builds and visible stats

Akira: technical all-rounder, with better control, clone setup, regeneration, sealing, solar utility and dangerous escalation.

Rikito: stronger physical baseline and sturdier frame, with layered demon states, dark finishers, slowing pressure and lunar recovery.

| Stat | Akira | Rikito |
| --- | --- | --- |
| Flow | 85 | 90 |
| Flux | 90 | 84 |
| Control | 92 | 84 |
| Strength | 70 | 94 |
| Constitution | 72 | 88 |
| Vitality | 82 | 86 |
| Movement Speed | 88 | 86 |
| Agility | 94 | 92 |
| Endurance | 78 | 90 |
| Willpower | 90 | 94 |
| Introspection | 88 | 90 |

The 1–120 stat scale is a provisional high-level scale. The builds have no unused stat points; editing the data file is the current way to change these values. Introspection and the tested cancel perk are already unlocked in both loadouts. No leveling/training loop is simulated.

| Base attribute | Akira | Rikito |
| --- | --- | --- |
| Maximum health | 2468 | 2564 |
| Native aether | 720 | 760 |
| Linked Spirit aether | 1175 | 882 |
| Total aether | 1895 | 1882 |
| Stamina | 508 | 580 |
| Will | 470 | 490 |
| Maximum Focus | 14 | 13 |
| Starting Focus | 6 | 6 |
| Charge gain | 6.625 | 6.250 |
| Passive Focus/tick | 0.113 | 0.105 |
| Physical defense | 144 | 176 |
| Aether defense | 72 | 88 |
| Melee potency | 150 | 198 |

## One pool with Spirit contributions

Maximum aether = 40 + 8 × Flow + completed-core bonus + sum of linked Spirit contributions.

Linked contribution = round(Spirit reserve proxy × min(0.90, 0.45 + Introspection / 200)).

The reserve proxies below stand in for relative Spirit capacity. The literature passages reviewed do not supply these game pool numbers. They are not canon Flow stats or a second spendable bar. Introspection links 89% of the listed Spirit reserves for Akira and 90% for Rikito.

### Akira Lyte

| Source | Reserve proxy | Linked amount | Test perk |
| --- | --- | --- | --- |
| Spirit of Utopia | 720 | 641 | 0.20 HP/tick while aether remains; no revival. |
| Helios | 600 | 534 | 0.35 aether/tick in sunlight; unlocks Solar Absorption and Solar Pressure. |
### Rikito

| Source | Reserve proxy | Linked amount | Test perk |
| --- | --- | --- | --- |
| Lunario | 980 | 882 | 15% less involuntary Focus loss; Lunar Reflection, Moon Drip and Lunar Pressure. |

Rikito additionally receives +240 aether from his completed Utopic core. This is not a second Spirit of Utopia: Utopia and Helios are bound to Akira; Lunario supports Rikito’s stabilized core. Disabling Spirit contributions for comparison removes their added capacity, passive perks and specific Spirit actions/blessings, but does not erase Rikito’s completed core or previously unlocked personal forms.

Blessings and active forms do not add Spirit capacity again. Switching off Solar/Lunar Pressure saves upkeep but does not reduce maximum aether. The Spirit of Utopia’s passive healing and Akira’s paid regeneration can coexist as explicitly separate test sources. Divine-tagged energy attacks gain ×1.08 potency once, not once per stacked form. God Breaker currently uses physical scaling and defense penetration instead of that energy multiplier. Environmental recovery is access-dependent, never unlimited in a sealed arena.

Helios passive recovery is 0.35 aether/tick under sunlight. Photoreception adds 1.10/tick while active but has its own 2.20/tick upkeep before other layers. Solar Absorption restores up to 180 aether and has a 60-tick cooldown. Moon Drip is once per spar and restores up to 45% max aether, 30% max stamina and 15% max health. Its canon full-restoration effect is deliberately compressed.

## Form stacking

The engine tracks compatibility slots: pressure, core, soul, amplifier, blessing, cloak, shroud and solarRoute. These are game categories; a Spirit blessing is not reclassified as a canon Form. Only one entry may occupy a slot. Multipliers from compatible layers multiply; their aether and Will upkeep add. No generic global damage multiplier cap is currently imposed.

| Layer | Slot | Physical ATK | Aether ATK | Physical DEF | Aether DEF | Physical SPD | Art SPD | Aether/tick | Will/tick |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Divine Pressure | pressure | 1.08 | 1.08 | 1.1 | 1.1 | 1 | 1 | 0.5 | 0 |
| Spirit Resonance | soul | 1.5 | 1 | 1.3 | 1 | 1.2 | 1 | 0.6 | 0.05 |
| True God of Utopia | core | 1.35 | 1.5 | 1.25 | 1.25 | 1 | 1 | 1.4 | 0 |
| Utopic Spirit Resonance | soul | 1.35 | 1.2 | 1.15 | 1.15 | 1 | 1 | 1.1 | 0.15 |
| Golden Energy Mode · Layer Z | amplifier | 1.2 | 1.2 | 1 | 1 | 1.1 | 1.1 | 0.9 | 0 |
| Full-Powered Solar Pressure | blessing | 1.08 | 1.08 | 1 | 1.1 | 1 | 1 | 0.3 | 0.1 |
| Exponential Spirit Resonance · 1 | soul | 1.2 | 1.2 | 1 | 1 | 1.05 | 1.05 | 1.8 | 0.2 |
| Exponential Spirit Resonance · 7 | soul | 1.8 | 1.8 | 1 | 1 | 1.15 | 1.15 | 3.6 | 0.35 |
| Exponential Spirit Resonance · 12 | soul | 2.2 | 2.2 | 1 | 1 | 1.22 | 1.22 | 5.1 | 0.55 |
| Photoreception · Earth’s Sun | solarRoute | 2.2 | 2.5 | 1.5 | 1.5 | 1.25 | 1.25 | 2.2 | 0 |
| Perfect Demon Form · Level 3 | core | 1.4 | 1.3 | 1.45 | 1.45 | 1 | 1 | 1.2 | 0 |
| Divine Demonic Spirit Resonance | soul | 1.25 | 1.25 | 1.15 | 1.15 | 1 | 1 | 1 | 0.15 |
| True Demonic Force | amplifier | 1.2 | 1.2 | 1 | 1 | 1 | 1 | 0.8 | 0.04 |
| Infuscate · Second Degree | shroud | 1.1 | 1.15 | 1.1 | 1.2 | 1 | 1 | 1.4 | 0.2 |
| Abyssal Lightning Cloak | cloak | 1.15 | 1 | 1 | 1 | 1.2 | 1.05 | 0.8 | 0 |
| Full-Powered Lunar Pressure | blessing | 1.08 | 1.08 | 1 | 1.1 | 1 | 1 | 0.3 | 0.1 |

### Presets and route rules

Akira War: Divine Pressure + True God of Utopia + Utopic Spirit Resonance + Golden Energy Mode Layer Z + Full-Powered Solar Pressure.

Akira Peak: Divine Pressure + True God of Utopia + Exponential Spirit Resonance, Twelfth Magnitude + Full-Powered Solar Pressure. Twelfth Magnitude costs an additional 2.5 HP per powered tick. It can defeat its own user; regeneration never revives someone whose HP reaches zero.

Rikito War: Divine Pressure + Perfect Demon Form Level Three + Divine Demonic Spirit Resonance + True Demonic Force + Abyssal Lightning Cloak + Full-Powered Lunar Pressure.

Rikito Peak: War layers plus Infuscate, Second Degree.

- Entering another soul state replaces SR, Utopic Spirit Resonance, Divine Demonic Spirit Resonance or Exponential Spirit Resonance in that slot.
- Exponential Spirit Resonance removes GEM and all current clones. No new astral arrays can be created while it is active. First → Seventh → Twelfth Magnitude are the sampled escalation steps. Replacing the Exponential state ends its strain.
- Photoreception uses Earth’s Sun as a single natural-star source. This implementation retains only Divine Pressure and the Solar blessing when it enters. Other layers require releasing that route first. An attacking Supernova is never also credited as a fuel source.
- Infuscate requires active Perfect Demon Form in this prototype. Dropping that core also removes Infuscate. This is an implementation gate, not a claim of a universal canon prerequisite.
- Divine Pressure reduces the aether cost of Arts by 15% and provides its own mild modifiers. It is not required to use all Divine aether. It also costs upkeep.
- Each active layer can be dropped from its card at a decision point for 5 recovery ticks, with no resource refund. Release all layers is also available. Paid temporary Arts such as regeneration have their own expiry rather than being silently erased by a voluntary form release.
- Empty aether drops every layer and sustained regeneration. Empty Will drops layers requiring ongoing Will. This is loss of control in the test—not the death or disappearance of a bound Spirit.

| Preset | Akira physical / aether ATK | Rikito physical / aether ATK | Akira / Rikito aether upkeep |
| --- | --- | --- | --- |
| war | 2.551 / 2.519 | 2.817 / 2.274 | 4.200 / 4.600 |
| peak | 3.464 / 3.849 | 3.099 / 2.616 | 7.300 / 6 |

## Actions and costs

Listed costs and startup/recovery are raw definitions, before Control, Divine Pressure, Agility and layer speed. F = Focus; A = shared aether; S = stamina; W = Will. All transformations use 10 startup/12 recovery except Divine Pressure (4/12) and Release all layers (0/8), before movement recovery reduction. Form Focus costs are fixed. Other positive Focus costs use max(1, ceil(base cost / (1 + Control / 100))). Move Cancel uses its own fixed cost.

### Akira Lyte

| Action | Category | Startup/RS | F/A/S/W | Potency or effect |
| --- | --- | --- | --- | --- |
| Quick strike | Attacks | 6/10 | 0/0/8/0 | Melee ×0.75 |
| Heavy strike | Attacks | 12/18 | 0/0/20/0 | Melee ×1.4 |
| Dragon’s Barrage | Attacks | 10/16 | 1/10/24/0 | Melee ×1.5 |
| God Breaker | Attacks | 12/20 | 3/45/20/10 | Melee ×2 |
| Utopic Star Destroyer | Arts | 16/20 | 3/35/0/0 | Energy 150 |
| Star Breaker | Arts | 26/27 | 6/80/0/0 | Energy 330 |
| True Utopic Stardust Breaker | Arts | 34/34 | 10/155/0/25 | Energy 650 |
| Nebulus | Utility | 10/14 | 2/35/0/0 | nebulus |
| Protos | Arts | 4/14 | 3/50/0/0 | Energy 200 |
| Supernova | Arts | 30/30 | 8/130/0/15 | Energy 480 |
| Sunburst · Last resort | Arts | 40/50 | 12/200/0/60 | Energy 1300 |
| Guard | Defense | 0/14 | 0/0/10/0 | guard |
| Evasive step | Defense | 2/14 | 1/0/22/0 | dodge |
| Dragon Shift | Defense | 2/12 | 2/24/0/0 | dodge |
| Astra Eidolon Array | Utility | 9/14 | 3/60/0/20 | clones |
| Astral Substitution | Defense | 1/10 | 1/12/0/5 | dodge |
| Dragon Festival | Ego & Spirit | 16/22 | 5/110/0/35 | seal |
| Blessed Kiss · Infinite Regenerations | Ego & Spirit | 8/18 | 3/70/0/20 | regen |
| Solar Absorption | Ego & Spirit | 18/18 | 2/0/0/30 | absorb |
| Charge | Utility | 12/12 | 0/0/4/0 | charge |
| Catch breath | Utility | 16/16 | 0/0/0/0 | rest |
| Read aether signature | Ego & Spirit | 8/12 | 0/0/0/15 | read |
| Ego pressure · Experimental | Ego & Spirit | 8/16 | 2/0/0/35 | pressure |
| Recenter · Experimental | Ego & Spirit | 18/18 | 0/0/12/0 | center |
| Ego brace · Experimental | Defense | 2/12 | 0/0/0/20 | brace |
| Release all layers | Forms | 0/8 | 0/0/0/0 | release |
| Divine Pressure | Forms | 4/12 | 2/0/0/8 | Layer dp |
| Spirit Resonance | Forms | 10/12 | 3/0/0/10 | Layer sr |
| True God of Utopia | Forms | 10/12 | 4/0/0/20 | Layer tgou |
| Utopic Spirit Resonance | Forms | 10/12 | 3/0/0/20 | Layer usr |
| Golden Energy Mode · Layer Z | Forms | 10/12 | 3/0/0/5 | Layer gem |
| Full-Powered Solar Pressure | Forms | 10/12 | 2/0/0/15 | Layer solar |
| Exponential Spirit Resonance · 1 | Forms | 10/12 | 3/0/0/25 | Layer esr1 |
| Exponential Spirit Resonance · 7 | Forms | 10/12 | 5/0/0/35 | Layer esr7 |
| Exponential Spirit Resonance · 12 | Forms | 10/12 | 6/0/0/45 | Layer esr12 |
| Photoreception · Earth’s Sun | Forms | 10/12 | 6/0/0/40 | Layer photo |

### Rikito

| Action | Category | Startup/RS | F/A/S/W | Potency or effect |
| --- | --- | --- | --- | --- |
| Quick strike | Attacks | 6/10 | 0/0/8/0 | Melee ×0.75 |
| Heavy strike | Attacks | 12/18 | 0/0/20/0 | Melee ×1.4 |
| Deep Crash | Attacks | 10/15 | 0/0/17/0 | Melee ×1.35 |
| Abyssal Ruination | Attacks | 12/19 | 3/40/24/0 | Melee ×2.05 |
| Black Lightning | Arts | 12/15 | 2/28/0/0 | Energy 125 |
| Dark Lightning Cannon | Arts | 18/20 | 3/38/0/0 | Energy 170 |
| Abyss Breaker | Arts | 26/27 | 6/85/0/0 | Energy 340 |
| Ruination Cannon | Arts | 33/32 | 9/145/0/20 | Energy 610 |
| Dark Ruin | Arts | 22/25 | 5/85/0/20 | Energy 150 |
| Midnight | Utility | 7/10 | 2/35/0/5 | midnight |
| Archaic | Utility | 9/13 | 3/55/0/20 | archaic |
| Guard | Defense | 0/14 | 0/0/10/0 | guard |
| Evasive step | Defense | 2/14 | 1/0/22/0 | dodge |
| Lunar Reflection | Defense | 4/16 | 3/60/0/30 | reflect |
| Moon Drip | Ego & Spirit | 14/22 | 4/0/0/100 | moondrip |
| Charge | Utility | 12/12 | 0/0/4/0 | charge |
| Catch breath | Utility | 16/16 | 0/0/0/0 | rest |
| Read aether signature | Ego & Spirit | 8/12 | 0/0/0/15 | read |
| Ego pressure · Experimental | Ego & Spirit | 8/16 | 2/0/0/35 | pressure |
| Recenter · Experimental | Ego & Spirit | 18/18 | 0/0/12/0 | center |
| Ego brace · Experimental | Defense | 2/12 | 0/0/0/20 | brace |
| Release all layers | Forms | 0/8 | 0/0/0/0 | release |
| Divine Pressure | Forms | 4/12 | 2/0/0/8 | Layer dp |
| Spirit Resonance | Forms | 10/12 | 3/0/0/10 | Layer sr |
| Perfect Demon Form · Level 3 | Forms | 10/12 | 3/0/0/15 | Layer pdf |
| Divine Demonic Spirit Resonance | Forms | 10/12 | 3/0/0/20 | Layer ddsr |
| True Demonic Force | Forms | 10/12 | 3/0/0/15 | Layer tdf |
| Infuscate · Second Degree | Forms | 10/12 | 4/0/0/25 | Layer inf |
| Abyssal Lightning Cloak | Forms | 10/12 | 2/0/0/8 | Layer alc |
| Full-Powered Lunar Pressure | Forms | 10/12 | 2/0/0/15 | Layer lunar |

## Key interactions and experimental Ego mechanics

- Astra Eidolon Array creates two clones for 50 ticks. Physical attacks gain +15% per clone as a compressed assistance effect, not a literal full-power duplicate of every attack. Astral Substitution consumes an existing clone at commitment and then provides one evasive window. It cannot invent a clone when none exists.
- Read aether signature grants two familiarity points. Being targeted by an energy attack adds one, capped at three. Dragon Festival requires two. It can nullify a pending enemy Art and suppress new Arts for 20 ticks. Ordinary physical strikes, mental-control actions and Spirit support remain available. Physical-damage Arts such as God Breaker still count as Arts for this restriction.
- Infinite Regenerations lasts 40 ticks, healing up to 1.8 HP/tick for 0.7 aether/tick after its activation costs. It is not immunity and cannot reverse Sunburst’s sacrifice.
- Dark Ruin adds a 24-tick slow: ×1.25 timing on new commitments. It does not retroactively extend an already-committed action.
- Midnight adds ×1.30 to the next dark attack within 60 ticks. Archaic adds ×1.35 to the next finisher within 60 ticks. They stack when both tags apply and are consumed at commitment even if the attack later misses or is cancelled.
- Lunar Reflection halves the first non-area energy Art hit in a 20-tick window and returns 40% of its damage before the counter. Guard/evasion are evaluated first. It does not reflect physical attacks or area Arts, and reflected damage does not recursively reflect.
- Guard reduces HP damage to 40% for 18 ticks. Committing an action outside the guard/dodge categories ends it. Evasion avoids one normal hit for 16 ticks; area damage still connects at 65% before other reductions.
- Ego pressure, Recenter and Ego brace are explicitly experimental interfaces to Will/Introspection, not new named canon Arts or invented Covenants. Pressure damages Will and Focus rather than HP and applies shaken for 20 ticks unless braced. Shaken halves passive Focus gain. Recenter restores up to 45 Will and removes slow/shaken; it does not remove Dragon Festival. Ego brace lasts 24 ticks and reduces pressure’s Will/Focus damage by 70%.
- Ego pressure Will loss = 70 × (1 − min(0.75, defender Introspection / 200)), then the brace factor. Its Focus loss uses Control retention; Lunario enhances that retained fraction in this prototype. Other involuntary heavy-hit Focus losses are reduced by a further 15% for Lunario’s host. These two paths should be unified if competitive balancing keeps this perk.
- Move Cancel is an experimental unlocked perk for Agility ≥85. During eligible startup it costs 3 Focus and 10 Will, retains original spent costs, cancels the action, grants 8 ticks of short Guard, and sets readiness 6 ticks later. Cooldown: 60 ticks. No recovery cancel, form/Spirit-action cancel or Sunburst cancel. The top-level button targets the chosen player character, including in local-control mode.
- Sunburst requires Photoreception and is deliberately a last resort: after its area damage, it empties aether and KOs Akira. Evasion or a surviving opponent does not waive that price. A draw is possible. Its detailed narrative meridian damage is not simulated.

## Attribute and event calculations

Maximum HP = 500 + 24 × Vitality. This is larger than the Arc I branch’s 100 + 12 × Vitality to support extended high-level exchanges.

Stamina = 40 + 6 × Endurance; Will = 20 + 5 × Willpower. Maximum Focus = 3 + floor(Flux / 8); starting Focus = 1 + floor(Flux / 16); Charge gain = 1 + Flux / 16; passive Focus = Flux / 800 per powered tick. Control retention = Control / (Control + 40). Resources retain fractional precision internally.

Physical defense rating = 2 × Constitution × active physical defense multipliers. Energy defense = Constitution × active aether defense multipliers. Basic melee = 10 + 2 × Strength. Damage = round(raw potency × 100 / (100 + applicable defense)), followed by the defined defensive factors in the engine. God Breaker ignores 30% of physical defense rating. A clone assistance factor applies to physical attacks, not every spell.

Physical startup = ceil(raw startup × slow / ((1 + Agility / 100) × physical layer speed)). Art startup = ceil(raw startup × slow / (Art layer speed × Akira’s 1.15 Flow Mastery speed factor, if applicable)). Other startup uses its raw value with slow. Nonzero startup has a one-tick minimum.

Recovery = ceil(raw recovery × (1 − min(0.25, Movement Speed / 400)) × slow / the relevant physical or Art layer speed), with a three-tick floor. Spirit and Ego actions do not receive the Art-speed multiplier. Costs are spent at commitment. Timings stay fixed; attack and defense layer multipliers are read at impact. Prepared Midnight/Archaic bonuses are reserved at commitment.

Each simulation tick pays upkeep, applies powered recovery and strain, handles resource-driven collapse, then resolves expiry/effect events. A partially funded final tick receives proportional aether-funded upkeep, healing and Focus. Helios replenishment happens after depletion checks: it may restore a little aether without automatically reactivating lost layers. States expire at the stated tick, before that tick’s action effects.

Same-tick support order: transformations; defense/Spirit support; non-damaging utility; then attack damage. Damage is batched before the knockout check, allowing simultaneous KOs. Dragon Festival can cancel an Art due that same tick because suppression resolves before attacks. Costs already paid are not refunded. This is an explicit game convention, not a universal canon statement. Healing/support effects can precede same-tick incoming damage; health never exceeds its maximum.

History names the cause and actual amount of each resource change. Continuous effects aggregate per actor/resource/cause between checkpoints. Snapshots are immutable copies. The test does not advance on real-world waiting time or while replaying.

## Visual implementation and limitations

New adult concept sprites preserve Akira’s taller black spikes and navy/gold outfit, and Rikito’s short compact fringe and black/reddish-brown outfit. Rikito’s adult face/body is an extrapolation from the supplied child portrait, not an approved final design. Each character has four-frame guard, strike and cast strips; several actions share those poses. Guard breathing is reused on profiles.

Frames are 128×144 with an approximate (64,136) foot anchor; strips are 512×144. They display with pixelated scaling at desktop/mobile sizes. Aura accents indicate creamy-white SR, golden Utopic/solar layers, dark-orange Exponential resonance and violet Demon layers. Spirit blessings have a small light marker. These are simplified state indicators. Infuscate’s exact skin/sigil transformation and all specialized Art shapes are not fully illustrated. Hit feedback remains a flash and number.

The adult atlas was produced with built-in image generation from the two supplied portraits, then chromakey-extracted and packed. Prompt intent: mature 4-head-tall pixel fighters; 4 columns × 6 rows; guard, punch and beam cast for each; consistent silhouettes; distinct hair; flat green extraction background; no aura or text. Runtime aura/VFX accents are code-native overlays.

## Source map

- Arc4_Full_Arc_Merged.docx, Chapter III “Cold World,” “Descent”: Akira’s war stack; Helios’s blessing; Rikito’s layered arrival. Text names Solar Pressure as a blessing rather than a personal Form.
- Same arc, “Magnitudes” and surrounding Acier exchanges: Exponential Spirit Resonance’s dark-orange column, black/white sparks, magnitude escalation, strain and tradeoff with the earlier resonance/array route.
- Same arc, “One Shall Fall” and the final Acier sequence: Photoreception from the Sun, Supernovas, True Utopic Stardust Breaker, expensive regeneration and sacrificial Sunburst. Post-death Primordial/Omni material is excluded.
- Arc IV’s Drain/Island exchanges: Dragon Festival, Dark Ruin, Moon Drip, Infuscate with pale sigils, Midnight and Archaic Ruination Cannon. Lunario supports the completed pseudo-Utopic core in the earlier training passage.
- LoU_Miscellaneous_Compiled.docx, Moves / Akira and Rikito: ability families and explicit signature/clone/solar constraints. Protos and Lunar Reflection are included as Moves-note techniques; direct use in the reviewed Arc IV passages was not established, so their timeline placement remains provisional.
- Current author instructions govern the shared-pool design. Older notes do not override later corrections separating Demon Forms from Daimonblood/Satanic Form or making Divine Pressure an efficiency aid rather than an absolute prerequisite.

## Verification and next balancing work

Automated logic tests cover Spirit pool contributions, form-slot compatibility, resource depletion, Will collapse, no revival through strain/healing, Moon Drip’s limit, pre-existing clone use, cancellation costs, sealing, reflection, shaken, simultaneous Guard/knockouts and six full bot-driven matches across Base/War/Peak with either player selected. A simulated-DOM smoke test covers profiles, categories, commitment, event stepping, replay, reset and local Rikito control. These tests do not establish browser layout quality or competitive balance; browser rendering still needs user testing.

Next tests: deliberately compare repeated low-cost attacks against expensive setups; test both sides manually; measure time-to-KO and unused resources; inspect how often a defensive read beats a finisher; compare Spirit-enabled/disabled and sunlit/sealed scenarios. Decide whether full-stack opening should be a competitive mode or only a test shortcut. Do not use the deterministic AI’s win rate as a PvP balance target.

The source files and balance-data.json in the handoff pack are editable. The release changelog records implemented changes; this reference records current v0.6 behavior and its unresolved choices.
