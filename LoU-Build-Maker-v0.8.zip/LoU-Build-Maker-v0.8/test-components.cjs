const assert=require('assert'),R=require('./build-rules.js'),G=require('./build-duel.js'),A=require('./art-model.js');
const make=()=>{const builds={akira:R.fresh('akira'),rikito:R.fresh('rikito')};for(const b of Object.values(builds))b.stats=[...R.data.people[b.id].stats];return new G(builds,{mode:'local'});};
let g=make(),a=g.actor('akira'),r=g.actor('rikito');
assert.equal(g.base('rikito').aether,760+Math.round(980*R.link(g.options.builds.rikito)));
const bare=R.fresh('rikito');bare.spirits=false;assert.equal(R.poolTotal(bare),48);assert(!Object.hasOwn(R.pool(bare),'core'));assert(!Object.hasOwn(g.d.people.rikito,'core'));
// Synthetic test attack: not assigned to the live catalog as a canon technique.
const m=g.d.moves.jab;m.components=[{channel:'physical',flat:100,melee:0},{channel:'aether',flat:100,melee:0}];m.a=0;m.st=8;m.timing={physical:1,aether:1};
let q=g.terms(a,m),parts=g.previewDamage(a,m);assert.equal(q.aether,0);assert.equal(q.stamina,8);assert.equal(q.raw,200);
const expected=100*100/(100+176)+100*100/(100+88);assert(Math.abs(parts.reduce((s,c)=>s+c.damage,0)-expected)<1e-8);
assert.equal(q.start,Math.ceil(m.s/((1+94/100+1.15)/2)));
g.enter(a,'sr');q=g.terms(a,m);assert.equal(q.components[0].raw,150);assert.equal(q.components[1].raw,100,'Physical-only form does not buff aether component');
g=make();a=g.actor('akira');r=g.actor('rikito');Object.assign(g.d.moves.jab,{components:m.components,timing:{physical:1,aether:0}});
r.status.reflect=100;const hpA=a.hp,hpR=r.hp;assert(g.commit('akira','jab').ok);g.t=a.pending.at;g.resolve();
assert.equal(hpR-r.hp,Math.round(100*100/276+0.5*100*100/188));assert.equal(hpA-a.hp,Math.round(.4*100*100/188));assert(!g.active(r,'reflect'));
g=make();a=g.actor('akira');r=g.actor('rikito');g.d.moves.jab.components=m.components;r.status.evade=100;const hp=r.hp;g.commit('akira','jab');g.t=a.pending.at;g.resolve();assert.equal(r.hp,hp);assert(!g.active(r,'evade'),'Evade consumed once for entire mixed attack');
g=make();a=g.actor('akira');r=g.actor('rikito');g.d.moves.jab.components=m.components;r.status.guard=100;const before=r.hp;g.commit('akira','jab');g.t=a.pending.at;g.resolve();assert.equal(before-r.hp,Math.round(expected*.4));
const e=g.capture('Mixed hit');assert(e.messages.some(x=>x.includes('component calculation')));assert.equal(e.resources.filter(x=>x.key==='hp').length,1,'One actual damage total, not duplicate component damage');
console.log('PASS: Core removal, independent costs/timing, mixed defenses, physical-only form effects, partial reflection, guard, evade and one damage ledger entry.');
