# Lyte of Utopia — Build Maker v0.8

Open index.html in a browser. Assign stats and equip moves for both characters, then Start spar. Each test-level-100 character has 990 points. Save / load builds exports JSON; export before closing to retain drafts. The HTML works offline with embedded sprites.

Read LoU-Combat-Design-Record.md for current formulas, slots, Spirit sharing and Art component rules. LoU-Combat-Changelog.md tracks releases through v0.8. history/ contains superseded records only.

Core capacity is now merged with Spirit contributions. Mixed damage is supported by the engine; existing live moves keep their previous damage channels until new parameters are provided. Form-family consolidation remains deferred.

For Ab: edit high-data.js, art-model.js and the builder/engine sources as appropriate, then run node build-high.cjs. No npm dependencies are needed. Run test-build.cjs, test-build-ui.cjs, test-components.cjs and the test-high*.cjs scripts with Node. DOM checks do not substitute for rendered browser/animation playtesting. Player JSON saves builds, not combat history or move definitions.
