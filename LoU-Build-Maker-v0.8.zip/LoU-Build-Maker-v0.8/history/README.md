Historical snapshots only. These contain superseded capacities, Will costs and progression rules. The parent folder master design record is authoritative for v0.8.
