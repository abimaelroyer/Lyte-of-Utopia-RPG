# Lyte of Utopia — Build maker v0.7

## Start here

Open index.html. Both adult characters are assigned test level 100 and start at 1 in every stat with 990 unspent points. Edit either character. Use previous stats restores that character's v0.5/v0.6 numerical spread at level 100 while retaining their current loadout. Refund all stats returns their full point budget.

Choose equipment in Loadout, resolve any prerequisite messages, then Start spar with both builds. A spar copies both drafts and starts in base. Changes made in the builder never alter that live match. You may leave points unspent. Switching to a lower level refunds all stats and fits the standard starter loadout to the new slot limits.

Save / load builds exports both characters as JSON, or accepts pasted/uploaded JSON. Imports require legal budgets and equipment. No automatic browser storage is used; export before closing if you want to keep your changes. Exports contain builds, not combat saves or event history.

## Levels and stats

These levels are game-design proposals, not canon character levels. Level range 1–100. Each stat has a free baseline of 1 and a cap of 120. Available allocation budget = 10 × (level − 1). Each increase of one stat costs one point. Baseline values do not consume the allocation budget.

The earlier adult stat spreads remain templates; their leftover points are available to assign. Lower-level previews retain the adult technique catalog and Rikito's completed core; they model slot/stat progression, not the character's actual chronological abilities at that age or point in the story.

| Attribute | Formula before forms |
| --- | --- |
| Health | 500 + 24 × Vitality |
| Native Aether | 40 + 8 × Flow |
| Shared Aether | Native + completed core + linked Spirit contributions |
| Stamina | 40 + 6 × Endurance |
| Maximum Focus | 3 + floor(Flux / 8) |
| Starting Focus | 1 + floor(Flux / 16) |
| Active Focus gain | 1 + Flux / 16 |
| Passive Focus / tick | Flux / 800, subject to funding/caps |
| Focus retention | Control / (Control + 40) |
| Melee potency | 10 + 2 × Strength |
| Physical / Aether defense | 2 × Constitution / Constitution |
| Physical attack speed | 1 + Agility / 100 |
| Movement recovery reduction | min(25%, Movement Speed / 400) |

Non-form positive Focus costs retain max(1, ceil(raw Focus / (1 + Control / 100))). Form Focus costs are fixed. Actual timings retain the preceding speed, recovery and form rules. The selected combat action previews costs/timing after your stats and current forms are applied.

## Slot progression

| Group | Initial capacity | Additional unlocks |
| --- | --- | --- |
| Normal attacks | 2 | Third at level 20 |
| Heavy attacks | 1 | Second at level 35 |
| Ultimate | 0 | One at level 60 |
| Guard | 1 | Basic Guard occupies this slot |
| Standard evade | 1 | Evasive step occupies this slot |
| Advanced defense | 0 | One at level 30 |
| Charge / stamina recovery | One each, fixed | Always equipped |
| Additional Utility | 1 | Second at 25, third at 50 |
| Prepared forms | 0 | Two at 20; third at 40; fourth at 60; fifth at 80 |

These level gates stand in for future story/quest unlocks. No quest system or earned progression is implemented. All catalog candidates within an unlocked group are available to choose, subject to the prerequisites below. A technique is equipped only once. Quick strike must occupy a Normal slot as a no-Focus/no-Aether fallback; it still costs stamina.

Physical and aether attacks share Attacks. The prior Arts and Ego & Spirit categories are removed. Retained support techniques use Utility. Signature remains a conceptual identity tag, not an extra slot or implemented power tier.

## Requirements and form preparation

- Astral Substitution requires Astra Eidolon Array equipped.
- Protos and Supernova require Nebulus equipped.
- Sunburst requires Photoreception equipped.
- Infuscate II requires Perfect Demon Form 3 equipped.
- Exponential 7 requires Exponential 1 equipped; Exponential 12 also requires 7. The three magnitudes occupy three prepared slots but count as one main-form family.
- At most two main-form families can be prepared. The prototype's main-family tags are SR, USR, Exponential, Photoreception, PDF3 and DDSR. These are provisional loadout classifications, not definitive canon taxonomy.
- Prepared options do not automatically activate or stack. Existing v0.6 slot/exclusion rules still govern active layers; a fuller canon compatibility mapping remains future work. A five-slot loadout necessarily trades off some of the earlier unrestricted stress-test stack.
- Dragon Festival gains familiarity by witnessing incoming energy Arts. Experimental Read, Ego pressure, Recenter and Ego brace are absent from the selectable catalog.

The empty-choice option is available in nonessential slots. Missing or incompatible prerequisites block starting a spar rather than silently adding free techniques. Having sufficient resources to use an equipped action is checked during combat; a legal build can still lack enough Focus to activate an expensive form until its stats improve.

## Optional Spirit scaling

Ego stats and the Spirits section unlock at test level 40. Linked share = min(0.90, (0.65 × Introspection + 0.35 × Willpower) / 120 × 0.90). The linked contribution of each Spirit is round(reserve proxy × linked share).

| Character / source | Reserve proxy |
| --- | --- |
| Akira / Spirit of Utopia | 720 |
| Akira / Helios | 600 |
| Rikito / Lunario | 980 |

Rikito's completed Utopic core adds a separate fixed 240 capacity. It persists when Spirits are disabled and in lower-level slot previews, because these remain adult-kit tests.

Introspection 40 enables passive perks. Perk strength = linked share / 0.90. Akira's Utopic healing scales up to 0.20 HP/tick, and Helios recovery up to 0.35 Aether/tick in sunlight. Rikito's reduction to involuntary attack-related Focus loss scales up to 15%. Healing/recovery are capped by resource maxima and retain funding requirements. Introspection 60 allows equipping Spirit-flagged techniques and Solar/Lunar blessings. Spirit techniques retain their previous active effect values; this release scales capacity and passive perks, not every individual technique.

Disabling a character's Spirits removes their linked capacity and passive perks. Equipped Spirit actions must be removed before starting. The UI shows each reserve and its resulting contribution. These numbers and gates are provisional, not a claim about canon Spirit stats.

## Will and hidden systems

Willpower remains an assignable attribute that helps Spirit sharing. No independent Will energy resource is used. Form/Art Will costs and Will upkeep are zeroed in the build adapter, and no Will meter is shown. Move Cancel costs 3 Focus with the earlier Agility 85 requirement and cooldown, with no Will payment.

Below level 40, Ego stats and Spirit controls are hidden. Below level 20, Forms has no prepared slots and is absent from the combat menu. Having no prepared forms also hides that category. The builder shows only unlocked slot groups. This does not implement a full per-technique story-unlock tree.

## Source handoff

- high-data.js retains the baseline source catalog. build-rules.js defines tiers, budgets, slots, gates and validation.
- build-duel.js adapts the base engine: installs chosen stats, removes experimental moves/Will costs, limits available actions and applies Spirit sharing.
- high-engine.js remains the underlying tick engine. Its optional bond hook supports the new passive scaling. Some unused legacy effect handlers remain internal; they cannot be equipped in this release.
- high-ui.js contains the draft builder and combat UI. high-view.js retains grouped history totals. high-lab.html/css contain layout.
- balance-data.json is the adjusted v0.7 runtime catalog snapshot, generated from baseline-stat drafts; it is not an importable player save. Use Save / load builds for player JSON.
- Run node build-high.cjs after edits. It embeds the existing assets and regenerates index.html, combat-fragment.html and balance-data.json.

## Changelog

v0.7: Added editable level/stat budgets, live derived attributes, slot-based loadouts, prerequisite validation, per-character Spirit scaling, JSON transfer and equipped-only combat. Combined attack categories; moved support techniques to Utility; removed experimental Ego actions and Will spending; hid locked systems. Retained the v0.6 resource-bar layout and history summaries.

v0.6: Streamlined panels and moved history to its own page with grouped upkeep, boons/flaws and expandable source causes.

v0.5: Introduced recovered adult Arc IV kits, stacking, Spirit capacity, advanced interactions and provisional adult sprite assets.

## Verification and limits

Run node test-build.cjs and node test-build-ui.cjs from this folder. Tests cover budgets, dependencies, form-family limits, Spirit scaling/gates, equipped-only actions, draft isolation, complete AI-driven duels, UI editing, hidden systems and JSON validation. The UI test uses a simulated DOM, not a rendered browser. Human browser/animation testing and balance work remain necessary. No new canon research or sprite generation was performed for v0.7; it reuses the preceding source-based catalog and visuals.


## v0.7.1 — Attribute comparison

The stats page now shows current → proposed base attribute values. Current is the character build applied to the combat engine, not its remaining HP/resources or active forms. Proposed is the editable draft. This baseline changes only when a new spar applies the drafts. Values display up to four decimal places so small passive gains remain visible. Added Focus-cost-factor and Spirit-link/perk-strength comparisons. No combat formulas or slot rules changed. Transformation-family consolidation is deferred until the author supplies the detailed form parameters.
