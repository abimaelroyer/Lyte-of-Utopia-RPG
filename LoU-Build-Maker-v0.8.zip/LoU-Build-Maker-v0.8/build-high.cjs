const fs=require('fs'),path=require('path'),source=__dirname,output=__dirname;
let css=fs.readFileSync(path.join(source,'high-lab.css'),'utf8');
for(const who of ['akira','rikito'])for(const mode of ['guard','strike','cast']){const bytes=fs.readFileSync(path.join(output,'assets',who+'_'+mode+'.png'));css+='#lou-high .sprite.'+who+'.'+mode+'{background-image:url(data:image/png;base64,'+bytes.toString('base64')+')}\n';}
css+='#lou-high .sprite.aura-white{background:radial-gradient(ellipse,transparent 42%,#fffff1bb 55%,transparent 70%);animation:none}\n';
const names=['high-data.js','art-model.js','build-rules.js','high-engine.js','build-duel.js','high-view.js','high-ui.js'];const script=names.map(n=>fs.readFileSync(path.join(source,n),'utf8')).join('\n');
let html=fs.readFileSync(path.join(source,'high-lab.html'),'utf8').replace('/* LAB_CSS */',css).replace('/* LAB_SCRIPT */',()=>script);
if(Buffer.byteLength(html)>1000000)throw Error('Inline size exceeded');
if(process.argv.includes('--inline'))fs.writeFileSync('/workspace/lou-build-maker.html',html);
const R=require('./build-rules.js'),G=require('./build-duel.js');
fs.writeFileSync(path.join(output,'balance-data.json'),JSON.stringify(new G({akira:R.fresh('akira'),rikito:R.fresh('rikito')}).d,null,2));
fs.writeFileSync(path.join(output,'combat-fragment.html'),html);
fs.writeFileSync(path.join(output,'index.html'),'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Lyte of Utopia — High-level combat v0.8</title></head><body style="margin:0">'+html+'</body></html>');
console.log('Built',Buffer.byteLength(html),'bytes');
