# Lyte of Utopia — Combat Design Record

Current playable version: **v0.8**. Updated 13 September 2026.

This is the current master specification. Numerical values, levels and slots are prototype proposals, not canon measurements. Earlier snapshots are preserved in history/ and the changelog. The adult catalog and sprites are retained from the preceding Arc IV prototype; this release does not claim new literature verification.

## Start here

Open index.html. Both adult characters are assigned test level 100 and start at 1 in every stat with 990 unspent points. Edit either character. Use previous stats restores that character's v0.5/v0.6 numerical spread at level 100 while retaining their current loadout. Refund all stats returns their full point budget.

Choose equipment in Loadout, resolve any prerequisite messages, then Start spar with both builds. A spar copies both drafts and starts in base. Changes made in the builder never alter that live match. You may leave points unspent. Switching to a lower level refunds all stats and fits the standard starter loadout to the new slot limits.

Save / load builds exports both characters as JSON, or accepts pasted/uploaded JSON. Imports require legal budgets and equipment. No automatic browser storage is used; export before closing if you want to keep your changes. Exports contain builds, not combat saves or event history.

## Levels and stats

These levels are game-design proposals, not canon character levels. Level range 1–100. Each stat has a free baseline of 1 and a cap of 120. Available allocation budget = 10 × (level − 1). Each increase of one stat costs one point. Baseline values do not consume the allocation budget.

The earlier adult stat spreads remain templates; their leftover points are available to assign. Lower-level previews retain the adult technique catalog ; they model slot/stat progression, not the character's actual chronological abilities at that age or point in the story.

| Attribute | Formula before forms |
| --- | --- |
| Health | 500 + 24 × Vitality |
| Native Aether | 40 + 8 × Flow |
| Shared Aether | Native + linked Spirit contributions |
| Stamina | 40 + 6 × Endurance |
| Maximum Focus | 3 + floor(Flux / 8) |
| Starting Focus | 1 + floor(Flux / 16) |
| Active Focus gain | 1 + Flux / 16 |
| Passive Focus / tick | Flux / 800, subject to funding/caps |
| Focus retention | Control / (Control + 40) |
| Melee potency | 10 + 2 × Strength |
| Physical / Aether defense | 2 × Constitution / Constitution |
| Physical attack speed | 1 + Agility / 100 |
| Movement recovery reduction | min(25%, Movement Speed / 400) |

Non-form positive Focus costs retain max(1, ceil(raw Focus / (1 + Control / 100))). Form Focus costs are fixed. Actual timings retain the preceding speed, recovery and form rules. The selected combat action previews costs/timing after your stats and current forms are applied.

## Slot progression

| Group | Initial capacity | Additional unlocks |
| --- | --- | --- |
| Normal attacks | 2 | Third at level 20 |
| Heavy attacks | 1 | Second at level 35 |
| Ultimate | 0 | One at level 60 |
| Guard | 1 | Basic Guard occupies this slot |
| Standard evade | 1 | Evasive step occupies this slot |
| Advanced defense | 0 | One at level 30 |
| Charge / stamina recovery | One each, fixed | Always equipped |
| Additional Utility | 1 | Second at 25, third at 50 |
| Prepared forms | 0 | Two at 20; third at 40; fourth at 60; fifth at 80 |

These level gates stand in for future story/quest unlocks. No quest system or earned progression is implemented. All catalog candidates within an unlocked group are available to choose, subject to the prerequisites below. A technique is equipped only once. Quick strike must occupy a Normal slot as a no-Focus/no-Aether fallback; it still costs stamina.

Physical and aether attacks share Attacks. The prior Arts and Ego & Spirit categories are removed. Retained support techniques use Utility. Signature remains a conceptual identity tag, not an extra slot or implemented power tier.

## Requirements and form preparation

- Astral Substitution requires Astra Eidolon Array equipped.
- Protos and Supernova require Nebulus equipped.
- Sunburst requires Photoreception equipped.
- Infuscate II requires Perfect Demon Form 3 equipped.
- Exponential 7 requires Exponential 1 equipped; Exponential 12 also requires 7. The three magnitudes occupy three prepared slots but count as one main-form family.
- At most two main-form families can be prepared. The prototype's main-family tags are SR, USR, Exponential, Photoreception, PDF3 and DDSR. These are provisional loadout classifications, not definitive canon taxonomy.
- Prepared options do not automatically activate or stack. Existing v0.6 slot/exclusion rules still govern active layers; a fuller canon compatibility mapping remains future work. A five-slot loadout necessarily trades off some of the earlier unrestricted stress-test stack.
- Dragon Festival gains familiarity by witnessing incoming energy Arts. Experimental Read, Ego pressure, Recenter and Ego brace are absent from the selectable catalog.

The empty-choice option is available in nonessential slots. Missing or incompatible prerequisites block starting a spar rather than silently adding free techniques. Having sufficient resources to use an equipped action is checked during combat; a legal build can still lack enough Focus to activate an expensive form until its stats improve.

## Optional Spirit scaling

Ego stats and the Spirits section unlock at test level 40. Linked share = min(0.90, (0.65 × Introspection + 0.35 × Willpower) / 120 × 0.90). The linked contribution of each Spirit is round(reserve proxy × linked share).

| Character / source | Reserve proxy |
| --- | --- |
| Akira / Spirit of Utopia | 720 |
| Akira / Helios | 600 |
| Rikito / Lunario | 980 |

Core is another term for Spirit pools, not an additional capacity source. The previous separate +240 on Rikito has been removed, not transferred to Lunario. Total Aether is native capacity plus the linked contribution from each Spirit exactly once. Disabling Spirits leaves native capacity only. With the previous adult stat template, Rikito now has 1,432 total Aether (760 native + 672 linked), down from 1,672. At all stats 1 he has 55 with Spirits, or 48 without. Akira's template remains 1,598.

Introspection 40 enables passive perks. Perk strength = linked share / 0.90. Akira's Utopic healing scales up to 0.20 HP/tick, and Helios recovery up to 0.35 Aether/tick in sunlight. Rikito's reduction to involuntary attack-related Focus loss scales up to 15%. Healing/recovery are capped by resource maxima and retain funding requirements. Introspection 60 allows equipping Spirit-flagged techniques and Solar/Lunar blessings. Spirit techniques retain their previous active effect values; this release scales capacity and passive perks, not every individual technique.

Disabling a character's Spirits removes their linked capacity and passive perks. Equipped Spirit actions must be removed before starting. The UI shows each reserve and its resulting contribution. These numbers and gates are provisional, not a claim about canon Spirit stats.

## Will and hidden systems

Willpower remains an assignable attribute that helps Spirit sharing. No independent Will energy resource is used. Form/Art Will costs and Will upkeep are zeroed in the build adapter, and no Will meter is shown. Move Cancel costs 3 Focus with the earlier Agility 85 requirement and cooldown, with no Will payment.

Below level 40, Ego stats and Spirit controls are hidden. Below level 20, Forms has no prepared slots and is absent from the combat menu. Having no prepared forms also hides that category. The builder shows only unlocked slot groups. This does not implement a full per-technique story-unlock tree.

## Source handoff

- high-data.js retains the baseline source catalog. build-rules.js defines tiers, budgets, slots, gates and validation.
- build-duel.js adapts the base engine: installs chosen stats, removes experimental moves/Will costs, limits available actions and applies Spirit sharing.
- high-engine.js remains the underlying tick engine. Its optional bond hook supports the new passive scaling. Some unused legacy effect handlers remain internal; they cannot be equipped in this release.
- high-ui.js contains the draft builder and combat UI. high-view.js retains grouped history totals. high-lab.html/css contain layout.
- balance-data.json is the adjusted v0.8 runtime catalog snapshot, generated from baseline-stat drafts; it is not an importable player save. Use Save / load builds for player JSON.
- Run node build-high.cjs after edits. It embeds the existing assets and regenerates index.html, combat-fragment.html and balance-data.json.

## Earlier release summary

v0.7: Added editable level/stat budgets, live derived attributes, slot-based loadouts, prerequisite validation, per-character Spirit scaling, JSON transfer and equipped-only combat. Combined attack categories; moved support techniques to Utility; removed experimental Ego actions and Will spending; hid locked systems. Retained the v0.6 resource-bar layout and history summaries.

v0.6: Streamlined panels and moved history to its own page with grouped upkeep, boons/flaws and expandable source causes.

v0.5: Introduced recovered adult Arc IV kits, stacking, Spirit capacity, advanced interactions and provisional adult sprite assets.

## Verification and limits

Run node test-build.cjs and node test-build-ui.cjs from this folder. Tests cover budgets, dependencies, form-family limits, Spirit scaling/gates, equipped-only actions, draft isolation, complete AI-driven duels, UI editing, hidden systems and JSON validation. The UI test uses a simulated DOM, not a rendered browser. Human browser/animation testing and balance work remain necessary. No new canon research or sprite generation was performed for v0.7; it reuses the preceding source-based catalog and visuals.


## v0.7.1 — Attribute comparison

The stats page now shows current → proposed base attribute values. Current is the character build applied to the combat engine, not its remaining HP/resources or active forms. Proposed is the editable draft. This baseline changes only when a new spar applies the drafts. Values display up to four decimal places so small passive gains remain visible. Added Focus-cost-factor and Spirit-link/perk-strength comparisons. No combat formulas or slot rules changed. Transformation-family consolidation is deferred until the author supplies the detailed form parameters.


## v0.8 — Independent Art components and merged Spirit capacity

Core capacity has been removed from calculations, current/proposed attribute comparisons, the Spirits panel and the runtime catalog. The internal form compatibility group formerly named core is now transformation; this rename does not change stacking.

An Art can combine physical damage, aetherical damage, resource costs, timing and utility effects independently. Spending Aether does not automatically add aetherical damage, and a physical-looking attack can have explicitly assigned aetherical damage. The existing catalog keeps its previous coefficients and damage channels; assigning specific mixed splits awaits the author's move parameters. No new live technique has been given an invented physical/aetherical split.

### Damage schema and calculation

`art-model.js` is shared by action previews and resolution. Each move has a `components` array. Each component has `channel` (physical or aether), `flat`, `melee`, `penetration` and optional `divine`. Its pre-defense potency is `(flat + melee × base melee potency) × matching form ATK`. Existing clone bonuses apply to physical components; explicitly divine aether components receive the retained 1.08 factor. Setup bonuses retain their existing values and are consumed once at commitment.

Each component is mitigated independently: `damage = raw × 100 / (100 + matching defense × (1 − penetration))`. Physical uses physical DEF; aether uses aether DEF. Guard applies its existing 0.4 factor to both. Evade is consumed once per whole attack (zero damage, or the retained 0.65 factor for area attacks). Lunar Reflection reacts only to non-area aetherical components: it halves that component and returns 40% of its pre-reflection, post-defense/guard/evade value. Physical components continue normally. Remaining component damage is summed and rounded once before a single capped HP deduction. Simultaneous hits retain the existing resolution rules.

The selected action shows unguarded damage, expandable component values, costs and timing basis. Preview damage is an estimate before temporary defense reactions. History retains one total damage entry, with component details in the raw explanation rather than duplicating the total in the summary.

### Costs, timing and effects

- Focus, Aether and stamina costs are independent of damage channel. No Will resource or costs are added back.
- `sealEligible` controls suppression; `efficiencyEligible` controls Divine Pressure's 15% Aether-cost reduction. Neither depends on spending Aether. Their initial values preserve the previous catalog's eligibility.
- `timing` has physical and aether weights. A positive sum normalizes them. Physical startup speed uses `(1 + Agility/100) × physical form SPD`; aether startup speed uses aether form SPD × the retained Akira 1.15 casting factor (Rikito 1). Mixed timings average those speeds by their weights. Zero/zero means fixed speed 1.
- Recovery uses the weighted form speed, then Movement's reduction; it does not get another Agility startup bonus. Startup is rounded up to at least one tick when nonzero; recovery is rounded up to at least three ticks. Existing Slow applies its 1.25 delay factor.
- Support effects remain explicit effects. An aura or Aether cost alone grants no extra damage, healing or status.
- Forms independently multiply physical/aether ATK, SPD and DEF. Active form multipliers multiply together; upkeep, healing and strain add. Base multipliers remain visible as ×1.00. No universal mixed-attack multiplier is added.

### Stat responsibilities and unimplemented ideas

Flow supplies native capacity; Flux supplies Focus capacity, starting Focus and gain; Control supplies retention and non-form Focus efficiency. Strength supplies melee potency. Constitution supplies both defense ratings. Vitality supplies maximum HP. Movement reduces recovery; Agility improves physical startup and gates Move Cancel. Endurance supplies stamina. Willpower and Introspection currently govern optional Spirit sharing, with Introspection also gating perks and techniques. There is no independent Arts-skill progression, trainable energy-potency stat, automatic stat-based HP/Aether/stamina regeneration, or usable Will pool in this build. Recovery only comes from explicit implemented effects.

Spirit Resonance remains creamy white; Rikito's demon treatment remains violet. Existing action animations, two-character combat display, category navigation and action previews are retained. Energy bars remain directly under health. Event stepping, replay snapshots and grouped form-upkeep/boon/flaw summaries retain detailed causes in expandable history. Replay never rewinds or changes the live fight.

Transformation-family consolidation (SR to higher ascensions, Exponential magnitudes and Demon levels sharing one prepared slot) is recorded as deferred, pending the author's parameters. Current stage slots and compatibility still apply. Story/trainer breakthroughs and training are design goals; current level gates only simulate their progression constraints.

### Verification for this release

Node checks cover component mitigation, mixed timing/cost independence, form-channel separation, partial reflection, Guard/Evade, one damage ledger entry, corrected capacity, build budgets, slot prerequisites, draft/application isolation, imports, hidden systems, attribute previews, history reconciliation and complete simulated matches. A synthetic mixed move is used in tests only. UI checks use a simulated DOM; rendered browser appearance and animation timing still need human playtesting.

The current source handoff adds `art-model.js`. Edit source files then run `node build-high.cjs`; generated HTML embeds assets and needs no server. Player JSON transfers builds, not move definitions or fight history; existing version-7 build JSON remains compatible. `balance-data.json` is a generated runtime reference, not a player save. The underlying legacy engine retains some unused Will/Ego handlers, but `BuildDuel` removes their availability and costs from this menu.


## Runtime catalog snapshot

Generated from v0.8. Costs here are raw Focus/Aether/stamina; Control, current forms and stats modify the combat preview. Startup/recovery are base ticks. Damage coefficients are pre-form, pre-defense. Eligibility and detailed flags are in balance-data.json.

| Technique | User | Category | F/A/S | Startup/recovery | Components | Effect / description |
|---|---|---|---|---|---|---|
| Quick strike | both | Attacks | 0/0/8 | 6/10 | physical: 0 + 0.75 × melee | Cheap pressure; no interruption. Physical startup scales with Agility. |
| Heavy strike | both | Attacks | 0/0/20 | 12/18 | physical: 0 + 1.4 × melee | Slower physical hit with Focus pressure. |
| Dragon’s Barrage | akira | Attacks | 1/10/24 | 10/16 | physical: 0 + 1.5 × melee | Multi-strike animation represented by one combined damage event. |
| God Breaker | akira | Attacks | 3/45/20 | 12/20 | physical: 0 + 2 × melee | Blue aether-coated strike; ignores 30% of defense rating (test interpretation). |
| Utopic Star Destroyer | akira | Attacks | 3/35/0 | 16/20 | aether: 150 + 0 × melee | Go-to golden beam; efficient with Control and Divine Pressure. |
| Star Breaker | akira | Attacks | 6/80/0 | 26/27 | aether: 330 + 0 × melee | Heavy gold beam; forces involuntary Focus loss after retention. |
| True Utopic Stardust Breaker | akira | Attacks | 10/155/0 | 34/34 | aether: 650 + 0 × melee | Late Arc IV finisher. High impact and meaningful commitment. |
| Nebulus | akira | Utility | 2/35/0 | 10/14 | None | Prepare stardust for Protos or Supernova. Lasts 80 ticks. |
| Protos | akira | Attacks | 3/50/0 | 4/14 | aether: 200 + 0 × melee | Fast lesser-star attack requiring a prepared Nebulus cloud. |
| Supernova | akira | Attacks | 8/130/0 | 30/30 | aether: 480 + 0 × melee | Heavy stellar orb; area impact only partly evadable. This test consumes it as an attack, never also as fuel. |
| Sunburst · Last resort | akira | Attacks | 12/200/0 | 40/50 | aether: 1300 + 0 × melee | Requires Photoreception. Empties aether and KOs the user at impact, even if evaded. Deliberately sacrificial; may end in a draw. |
| Deep Crash | rikito | Attacks | 0/0/17 | 10/15 | physical: 0 + 1.35 × melee | Reliable physical entry. |
| Abyssal Ruination | rikito | Attacks | 3/40/24 | 12/19 | physical: 0 + 2.05 × melee | Lightning-cloaked rush; fast pressure with a stamina commitment. |
| Black Lightning | rikito | Attacks | 2/28/0 | 12/15 | aether: 125 + 0 × melee | Low-cost dark lightning. Useful when expensive finishers are unsafe. |
| Dark Lightning Cannon | rikito | Attacks | 3/38/0 | 18/20 | aether: 170 + 0 × melee | Go-to ranged pressure. |
| Abyss Breaker | rikito | Attacks | 6/85/0 | 26/27 | aether: 340 + 0 × melee | Dense black-violet orb and Focus pressure. |
| Ruination Cannon | rikito | Attacks | 9/145/0 | 33/32 | aether: 610 + 0 × melee | Major beam finisher. Benefits from prepared Midnight and Archaic. |
| Dark Ruin | rikito | Attacks | 5/85/0 | 22/25 | aether: 150 + 0 × melee | Damaging ruin field: +25% new action timings for 24 ticks. Existing commitments are unchanged. |
| Midnight | rikito | Utility | 2/35/0 | 7/10 | None | Next dark attack within 60 ticks gains ×1.30 damage. Consumed on commitment. |
| Archaic | rikito | Utility | 3/55/0 | 9/13 | None | Next finisher within 60 ticks gains ×1.35 damage. Can combine with Midnight. |
| Guard | both | Defense | 0/0/10 | 0/14 | None | Take 40% damage for 18 ticks. A new commitment ends Guard; Ego pressure is separate. |
| Evasive step | both | Defense | 1/0/22 | 2/14 | None | Evade one hit for 16 ticks. Area attacks still deal 65% damage. |
| Dragon Shift | akira | Defense | 2/24/0 | 2/12 | None | Teleport evasion for one incoming hit. Area attacks still partly connect. |
| Astra Eidolon Array | akira | Utility | 3/60/0 | 9/14 | None | Create two pre-existing clones for 50 ticks. Physical attacks gain 15% per clone; substitution consumes one. Excludes Exponential states. |
| Astral Substitution | akira | Defense | 1/12/0 | 1/10 | None | Consume an existing clone to enable a one-hit evasive swap. Cannot create a clone by itself. |
| Dragon Festival | akira | Utility | 5/110/0 | 16/22 | None | Requires 2 signature familiarity. Cancel an enemy pending Art, then suppress their Arts for 20 ticks. Not an Ego attack. |
| Blessed Kiss · Infinite Regenerations | akira | Utility | 3/70/0 | 8/18 | None | For 40 ticks, restore up to 1.8 HP/tick for 0.7 aether/tick. Costly regeneration, not immortality. |
| Solar Absorption | akira | Utility | 2/0/0 | 18/18 | None | Helios draws 180 aether from sunlight. 60-tick cooldown; unavailable in a sealed arena. |
| Lunar Reflection | rikito | Defense | 3/60/0 | 4/16 | None | For 20 ticks, halve the first non-area energy Art hit and return 40% of its pre-counter damage. Misc-listed counter; exact Arc IV placement and mechanics are provisional. |
| Moon Drip | rikito | Utility | 4/0/0 | 14/22 | None | Once per spar: restore 45% max aether, 30% max stamina and 15% max HP. Canon restoration compressed for this test. |
| Charge | both | Utility | 0/0/4 | 12/12 | None | Gain Flux-based Focus; cannot charge with zero aether or full Focus. |
| Catch breath | both | Utility | 0/0/0 | 16/16 | None | Restore up to 60 stamina. No aether or Will recovery. |
| Release all layers | both | Forms | 0/0/0 | 0/8 | None | Return to base and end all ongoing form upkeep. Temporary Arts remain until their duration ends. |
| Divine Pressure | both | Forms | 2/0/0 | 4/12 | None | Divine circulation: Art aether costs −15%. Efficiency aid, not a universal Divine prerequisite. |
| Spirit Resonance | both | Forms | 3/0/0 | 10/12 | None | Physical emphasis. Creamy-white aura. Replaces other soul-resonance states. |
| True God of Utopia | akira | Forms | 4/0/0 | 10/12 | None | Golden Utopic transformation; compatible with the war stack. |
| Utopic Spirit Resonance | akira | Forms | 3/0/0 | 10/12 | None | Soul Resonance layer; replaces SR or Exponential Spirit Resonance. |
| Golden Energy Mode · Layer Z | akira | Forms | 3/0/0 | 10/12 | None | Golden corona. Incompatible with Exponential Spirit Resonance and Photoreception mode. |
| Full-Powered Solar Pressure | akira | Forms | 2/0/0 | 10/12 | None | Helios’s blessing, not a Form. Compatible with either advanced Akira route. |
| Exponential Spirit Resonance · 1 | akira | Forms | 3/0/0 | 10/12 | None | First Magnitude. Removes GEM and clones; excludes new arrays. Requires an available environment. |
| Exponential Spirit Resonance · 7 | akira | Forms | 5/0/0 | 10/12 | None | Seventh Magnitude. Escalate from an active Exponential state; higher upkeep. |
| Exponential Spirit Resonance · 12 | akira | Forms | 6/0/0 | 10/12 | None | Twelfth Magnitude. 2.5 HP/tick strain. Requires Seventh Magnitude first; dangerous to sustain. |
| Photoreception · Earth’s Sun | akira | Forms | 6/0/0 | 10/12 | None | Natural-star route. Keeps only Divine Pressure and Solar blessing. Requires sunlight; not stacked with Exponential or GEM. |
| Perfect Demon Form · Level 3 | rikito | Forms | 3/0/0 | 10/12 | None | Demon transformation with dark sigils. Gentle test regeneration; not a Daimonblood/Satanic Form. |
| Divine Demonic Spirit Resonance | rikito | Forms | 3/0/0 | 10/12 | None | Soul Resonance layer; shares the soul slot with SR. |
| True Demonic Force | rikito | Forms | 3/0/0 | 10/12 | None | Deeper violet-black output; stacks with Demon Form and soul resonance. |
| Infuscate · Second Degree | rikito | Forms | 4/0/0 | 10/12 | None | Darkened frame and pale sigils in canon. Test prerequisite: active Perfect Demon Form. |
| Abyssal Lightning Cloak | rikito | Forms | 2/0/0 | 10/12 | None | Black-violet lightning coat for speed and physical pressure. |
| Full-Powered Lunar Pressure | rikito | Forms | 2/0/0 | 10/12 | None | Lunario’s blessing, not a Form. Silver-blue motes over the underlying stack. |

### Active form multipliers

Omitted multipliers default to 1. Costs below are per tick; activation Focus is fixed. Form names include techniques/states provisionally placed in the Forms menu. Prepared slots and compatibility are separate constraints.

| Form | Group | Physical ATK/SPD/DEF | Aether ATK/SPD/DEF | Focus | Aether upkeep | HP healing / strain |
|---|---|---|---|---|---|---|
| Divine Pressure | pressure | 1.08/1/1.1 | 1.08/1/1.1 | 2 | 0.5 | 0 / 0 |
| Spirit Resonance | soul | 1.5/1.2/1.3 | 1/1/1 | 3 | 0.6 | 0 / 0 |
| True God of Utopia | transformation | 1.35/1/1.25 | 1.5/1/1.25 | 4 | 1.4 | 0 / 0 |
| Utopic Spirit Resonance | soul | 1.35/1/1.15 | 1.2/1/1.15 | 3 | 1.1 | 0 / 0 |
| Golden Energy Mode · Layer Z | amplifier | 1.2/1.1/1 | 1.2/1.1/1 | 3 | 0.9 | 0 / 0 |
| Full-Powered Solar Pressure | blessing | 1.08/1/1 | 1.08/1/1.1 | 2 | 0.3 | 0 / 0 |
| Exponential Spirit Resonance · 1 | soul | 1.2/1.05/1 | 1.2/1.05/1 | 3 | 1.8 | 0 / 0 |
| Exponential Spirit Resonance · 7 | soul | 1.8/1.15/1 | 1.8/1.15/1 | 5 | 3.6 | 0 / 0 |
| Exponential Spirit Resonance · 12 | soul | 2.2/1.22/1 | 2.2/1.22/1 | 6 | 5.1 | 0 / 2.5 |
| Photoreception · Earth’s Sun | solarRoute | 2.2/1.25/1.5 | 2.5/1.25/1.5 | 6 | 2.2 | 0 / 0 |
| Perfect Demon Form · Level 3 | transformation | 1.4/1/1.45 | 1.3/1/1.45 | 3 | 1.2 | 0.12 / 0 |
| Divine Demonic Spirit Resonance | soul | 1.25/1/1.15 | 1.25/1/1.15 | 3 | 1 | 0 / 0 |
| True Demonic Force | amplifier | 1.2/1/1 | 1.2/1/1 | 3 | 0.8 | 0 / 0 |
| Infuscate · Second Degree | shroud | 1.1/1/1.1 | 1.15/1/1.2 | 4 | 1.4 | 0 / 0 |
| Abyssal Lightning Cloak | cloak | 1.15/1.2/1 | 1/1.05/1 | 2 | 0.8 | 0 / 0 |
| Full-Powered Lunar Pressure | blessing | 1.08/1/1 | 1.08/1/1.1 | 2 | 0.3 | 0 / 0 |
