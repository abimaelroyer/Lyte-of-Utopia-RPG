const assert=require('assert'),R=require('./build-rules.js'),Duel=require('./build-duel.js');
const make=()=>({akira:R.fresh('akira'),rikito:R.fresh('rikito')});
let b=make();assert.equal(R.budget(b.akira),990);assert.equal(R.spent(b.akira),0);assert.deepEqual(R.errors(b.akira),[]);
b.akira.stats=Array(11).fill(120);assert(R.errors(b.akira).some(x=>x.includes('Refund')));
b=make();b.akira.loadout.advanced=['substitute'];assert(R.errors(b.akira).length===0);b.akira.loadout.utility[0]='';assert(R.errors(b.akira).some(x=>x.includes('Astra')));
b=make();b.akira.loadout.forms=['esr1','esr7','esr12','dp','tgou'];assert.deepEqual(R.errors(b.akira),[]);
b.akira.loadout.forms=['esr12','','','',''];assert(R.errors(b.akira).some(x=>x.includes('7')));
b=make();b.akira.loadout.utility[0]='solarabsorb';assert(R.errors(b.akira).some(x=>x.includes('Introspection')));b.akira.stats[10]=60;assert.deepEqual(R.errors(b.akira),[]);
const p0=R.poolTotal(b.akira);b.akira.stats[9]=100;assert(R.poolTotal(b.akira)>p0);b.akira.spirits=false;assert.equal(R.pool(b.akira).spirit,0);assert(R.errors(b.akira).length);
b=make();for(const x of Object.values(b))x.stats=[...R.data.people[x.id].stats];let g=new Duel(b);assert.equal(g.base('akira').will,0);assert(g.base('akira').spirit>0);assert.equal(g.terms(g.actor('akira'),g.d.moves.regen).will,0);
assert(!g.available(g.actor('akira')).some(m=>['read','pressure','center','brace'].includes(m.id)));assert(g.available(g.actor('akira')).every(m=>['Attacks','Defense','Utility','Forms'].includes(m.cat)));
assert(g.reason(g.actor('akira'),g.d.moves.sunburst).includes('not equipped'));const pool=g.base('akira').aether;b.akira.stats[0]=1;assert.equal(g.base('akira').aether,pool,'Running match isolated from draft');
for(const player of ['akira','rikito']){b=make();for(const x of Object.values(b))x.stats=[...R.data.people[x.id].stats];g=new Duel(b,{player});let n=0;while(!g.over&&n++<2500){const w=g.decision();if(w)assert(g.submit(w.id,g.chooseAI(w)).ok);else g.next();}assert(g.over);console.log('Completed equipped duel:',player,g.t,'ticks');}
b=make();for(const x of Object.values(b)){x.level=1;const cap=R.slots(1);for(const k of Object.keys(cap))x.loadout[k]=x.loadout[k].slice(0,cap[k]);}g=new Duel(b);assert.equal(g.base('akira').spirit,0);assert(!g.available(g.actor('akira')).some(m=>m.form));
console.log('PASS: budgets, prerequisites, form families, Spirit gates/scaling, equipped-only combat, draft isolation and progression.');
