/* Damage, resource spending and timing are independent properties. */
const ArtModel=(()=>{
 function components(m){return m.components||[...(m.coef?[{channel:'physical',flat:0,melee:m.coef,penetration:m.pierce||0}]:[]),...(m.power?[{channel:'aether',flat:m.power,melee:0,penetration:m.pierce||0,divine:!!m.divine}]:[])];}
 function timing(m){return m.timing||{physical:m.type==='physical'?1:0,aether:m.type==='aether'?1:0};}
 function prepare(m){m.components=components(m);m.timing=timing(m);m.sealEligible=m.sealEligible??(m.type==='aether'||!!m.art);m.efficiencyEligible=m.efficiencyEligible??(m.type==='aether'||!!m.art);return m;}
 function terms(g,w,m){
  const b=g.base(w.id),s=g.d.people[w.id].stats,z=g.multipliers(w),slow=g.active(w,'slow')?1.25:1,t=timing(m),sum=t.physical+t.aether;
  const speed=sum?(t.physical*b.attack*z.sp+t.aether*z.cs*(w.id==='akira'?1.15:1))/sum:1;
  const recoverySpeed=sum?(t.physical*z.sp+t.aether*z.cs)/sum:1;
  const q={focus:m.type==='form'?m.f:(m.f?Math.max(1,Math.ceil(m.f/(1+s[2]/100))):0),aether:Math.ceil(m.a*(w.layers.includes('dp')&&(m.efficiencyEligible??(m.type==='aether'||m.art))?.85:1)),stamina:m.st,will:m.w};
  q.start=m.s?Math.max(1,Math.ceil(m.s*slow/speed)):0;q.recovery=Math.max(3,Math.ceil(m.r*(1-b.recovery)*slow/recoverySpeed));
  let buff=1;if(m.dark&&g.active(w,'midnight'))buff*=1.3;if(m.finisher&&g.active(w,'archaic'))buff*=1.35;
  q.components=components(m).map(c=>({...c,raw:((c.flat||0)+b.melee*(c.melee||0))*(c.channel==='physical'?z.p*(1+.15*w.clones):z.a*(c.divine?1.08:1))*buff}));
  q.raw=q.components.reduce((sum,c)=>sum+c.raw,0);return q;
 }
 function mitigate(g,target,parts,bonus=1){const b=g.base(target.id),z=g.multipliers(target);return parts.map(c=>{const rating=(c.channel==='physical'?b.physical*z.d:b.energy*z.e)*(1-(c.penetration||0));return {...c,damage:c.raw*bonus*100/(100+rating)};});}
 function totals(parts,key='damage'){return parts.reduce((a,c)=>{a[c.channel]+=c[key]||0;return a;},{physical:0,aether:0});}
 return {components,timing,prepare,terms,mitigate,totals};
})();
if(typeof module!=='undefined')module.exports=ArtModel;
