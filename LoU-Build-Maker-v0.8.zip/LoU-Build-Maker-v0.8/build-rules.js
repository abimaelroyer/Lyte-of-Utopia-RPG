/* Game-design proposals; not canon levels, tiers or Spirit reserve measurements. */
const BuildRules=(()=>{
const data=typeof HighData!=='undefined'?HighData:require('./high-data.js');
const removed=new Set(['pressure','center','brace','read']);
const tiers={normal:['jab','barrage','star','deep','lightning','cannon','protos'],heavy:['heavy','godbreaker','breaker','supernova','rush','abyss','darkruin'],ultimate:['stardust','sunburst','ruination']};
const main=new Set(['sr','usr','esr1','esr7','esr12','photo','pdf','ddsr']);
function category(m){return m.cat==='Arts'?'Attacks':m.cat==='Ego & Spirit'?'Utility':m.cat;}
function slots(level){return {normal:level>=20?3:2,heavy:level>=35?2:1,ultimate:level>=60?1:0,guard:1,evade:1,advanced:level>=30?1:0,utility:1+(level>=25?1:0)+(level>=50?1:0),forms:level<20?0:2+(level>=40?1:0)+(level>=60?1:0)+(level>=80?1:0)};}
function fresh(id){return {id,level:100,stats:Array(11).fill(1),spirits:true,loadout:{normal:id==='akira'?['jab','star','barrage']:['jab','deep','lightning'],heavy:id==='akira'?['heavy','breaker']:['heavy','abyss'],ultimate:[id==='akira'?'stardust':'ruination'],guard:['guard'],evade:['dodge'],advanced:[id==='akira'?'shift':''],utility:id==='akira'?['clones','regen','festival']:['midnight','archaic',''],forms:id==='akira'?['dp','tgou','usr','gem','']:['dp','pdf','tdf','alc','inf']}};}
function budget(b){return (b.level-1)*10;}
function spent(b){return b.stats.reduce((s,n)=>s+n-1,0);}
function link(b){return b.spirits&&b.level>=40?Math.min(.9,(b.stats[10]*.65+b.stats[9]*.35)/120*.9):0;}
function perk(b){return b.stats[10]>=40?link(b)/.9:0;}
function pool(b){const p=data.people[b.id];return {native:40+8*b.stats[0],spirit:p.spirits.reduce((s,x)=>s+Math.round(x.capacity*link(b)),0)};}
function poolTotal(b){const p=pool(b);return p.native+p.spirit;}
function candidates(id,slot){return Object.values(data.moves).filter(m=>!removed.has(m.id)&&(m.who==='both'||m.who===id)&&(
 tiers[slot]?tiers[slot].includes(m.id):slot==='guard'?m.id==='guard':slot==='evade'?m.id==='dodge':slot==='advanced'?['shift','substitute','reflection'].includes(m.id):slot==='utility'?category(m)==='Utility'&&!['charge','breath'].includes(m.id):slot==='forms'?!!m.form:false));}
function equipped(b){const cap=slots(b.level);return ['charge','breath',...Object.entries(b.loadout).flatMap(([slot,ids])=>ids.slice(0,cap[slot]||0).filter(Boolean)),...(cap.forms&&b.loadout.forms.some(Boolean)?['release']:[])];}
function errors(b){const out=[];if(!Number.isInteger(b.level)||b.level<1||b.level>100)out.push('Level must be 1–100.');if(b.stats.length!==11||b.stats.some(n=>!Number.isInteger(n)||n<1||n>120))out.push('Stats must be whole numbers from 1–120.');if(spent(b)>budget(b))out.push('Refund '+(spent(b)-budget(b))+' stat points.');if(b.level<40&&b.stats.slice(9).some(n=>n!==1))out.push('Refund Ego stats before testing below level 40.');
 const cap=slots(b.level),ids=equipped(b);
 for(const [slot,n] of Object.entries(cap)){const selected=b.loadout[slot]||[];if(selected.slice(n).some(Boolean))out.push('Clear locked '+slot+' slots.');for(const key of selected.filter(Boolean))if(!candidates(b.id,slot).some(m=>m.id===key))out.push('Invalid '+slot+' choice: '+key);}
 if(new Set(ids).size!==ids.length)out.push('Each technique can occupy only one slot.');
 if(!ids.includes('jab'))out.push('Equip Quick strike in a Normal slot as the stamina-only fallback.');
 if(!ids.includes('guard')||!ids.includes('dodge'))out.push('Equip the standard Guard and Evade.');
 if(new Set(b.loadout.forms.filter(k=>main.has(k)).map(k=>k.startsWith('esr')?'esr':k)).size>2)out.push('Prepare at most two main-transformation options.');
 for(const key of ids){const m=data.moves[key];if((m.spirit||m.form&&data.forms[m.form].spirit)&&(!b.spirits||b.level<40||b.stats[10]<60))out.push(m.name+' requires Spirits enabled and Introspection 60.');}
 const needs=[['substitute','clones'],['protos','nebulus'],['supernova','nebulus'],['sunburst','photo'],['inf','pdf'],['esr7','esr1'],['esr12','esr7']];
 for(const [m,req] of needs)if(ids.includes(m)&&!ids.includes(req))out.push(data.moves[m].name+' needs '+data.moves[req].name+' equipped.');
 return [...new Set(out)];}
return {data,removed,tiers,main,category,slots,fresh,budget,spent,link,perk,pool,poolTotal,candidates,equipped,errors};
})();
if(typeof module!=='undefined')module.exports=BuildRules;
