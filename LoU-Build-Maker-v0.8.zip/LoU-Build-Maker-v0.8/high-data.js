/* LoU v0.8 high-level lab. Numbers are game-design proposals, not canon Yield. */
const HighData=(()=>{
const keys=['Flow','Flux','Control','Strength','Constitution','Vitality','Movement Speed','Agility','Endurance','Willpower','Introspection'];
const people={
akira:{name:'Akira Lyte',race:'Kaelithian / Utopian',era:'Adult · recovered Arc IV kit',style:'Technical all-rounder: clone setups, sealing, solar control and risky escalation.',stats:[85,90,92,70,72,82,88,94,78,90,88],spirits:[{name:'Spirit of Utopia',capacity:720,perk:'0.20 HP/tick while aether remains; no revival.'},{name:'Helios',capacity:600,perk:'0.35 aether/tick in sunlight; unlocks Solar Absorption and Solar Pressure.'}]},
rikito:{name:'Rikito',race:'Dystopian / Kaelithian',era:'Adult · recovered Arc IV kit',style:'Pressure fighter: layered demon states, disruption, ruin finishers and lunar recovery.',stats:[90,84,84,94,88,86,86,92,90,94,90],spirits:[{name:'Lunario',capacity:980,perk:'15% less involuntary Focus loss; Lunar Reflection, Moon Drip and Lunar Pressure.'}]}
};
// Slot = compatibility group, not a claim that every entry is a canon Form.
const forms={
dp:{name:'Divine Pressure',slot:'pressure',p:1.08,a:1.08,d:1.1,e:1.1,flow:.5,focus:2,will:8,desc:'Divine circulation: Art aether costs −15%. Efficiency aid, not a universal Divine prerequisite.'},
sr:{name:'Spirit Resonance',slot:'soul',p:1.5,d:1.3,sp:1.2,flow:.6,willTick:.05,focus:3,will:10,desc:'Physical emphasis. Creamy-white aura. Replaces other soul-resonance states.'},
tgou:{name:'True God of Utopia',who:'akira',slot:'transformation',p:1.35,a:1.5,d:1.25,e:1.25,flow:1.4,focus:4,will:20,desc:'Golden Utopic transformation; compatible with the war stack.'},
usr:{name:'Utopic Spirit Resonance',who:'akira',slot:'soul',p:1.35,a:1.2,d:1.15,e:1.15,flow:1.1,willTick:.15,focus:3,will:20,desc:'Soul Resonance layer; replaces SR or Exponential Spirit Resonance.'},
gem:{name:'Golden Energy Mode · Layer Z',who:'akira',slot:'amplifier',p:1.2,a:1.2,sp:1.1,cs:1.1,flow:.9,focus:3,will:5,desc:'Golden corona. Incompatible with Exponential Spirit Resonance and Photoreception mode.'},
solar:{name:'Full-Powered Solar Pressure',who:'akira',slot:'blessing',p:1.08,a:1.08,e:1.1,flow:.3,willTick:.1,focus:2,will:15,spirit:true,desc:'Helios’s blessing, not a Form. Compatible with either advanced Akira route.'},
esr1:{name:'Exponential Spirit Resonance · 1',who:'akira',slot:'soul',p:1.2,a:1.2,sp:1.05,cs:1.05,flow:1.8,willTick:.2,focus:3,will:25,mag:1,desc:'First Magnitude. Removes GEM and clones; excludes new arrays. Requires an available environment.'},
esr7:{name:'Exponential Spirit Resonance · 7',who:'akira',slot:'soul',p:1.8,a:1.8,sp:1.15,cs:1.15,flow:3.6,willTick:.35,focus:5,will:35,mag:7,desc:'Seventh Magnitude. Escalate from an active Exponential state; higher upkeep.'},
esr12:{name:'Exponential Spirit Resonance · 12',who:'akira',slot:'soul',p:2.2,a:2.2,sp:1.22,cs:1.22,flow:5.1,willTick:.55,focus:6,will:45,mag:12,strain:2.5,desc:'Twelfth Magnitude. 2.5 HP/tick strain. Requires Seventh Magnitude first; dangerous to sustain.'},
photo:{name:'Photoreception · Earth’s Sun',who:'akira',slot:'solarRoute',p:2.2,a:2.5,d:1.5,e:1.5,sp:1.25,cs:1.25,flow:2.2,focus:6,will:40,desc:'Natural-star route. Keeps only Divine Pressure and Solar blessing. Requires sunlight; not stacked with Exponential or GEM.'},
pdf:{name:'Perfect Demon Form · Level 3',who:'rikito',slot:'transformation',p:1.4,a:1.3,d:1.45,e:1.45,flow:1.2,heal:.12,focus:3,will:15,desc:'Demon transformation with dark sigils. Gentle test regeneration; not a Daimonblood/Satanic Form.'},
ddsr:{name:'Divine Demonic Spirit Resonance',who:'rikito',slot:'soul',p:1.25,a:1.25,d:1.15,e:1.15,flow:1,willTick:.15,focus:3,will:20,desc:'Soul Resonance layer; shares the soul slot with SR.'},
tdf:{name:'True Demonic Force',who:'rikito',slot:'amplifier',p:1.2,a:1.2,flow:.8,willTick:.04,focus:3,will:15,desc:'Deeper violet-black output; stacks with Demon Form and soul resonance.'},
inf:{name:'Infuscate · Second Degree',who:'rikito',slot:'shroud',p:1.1,a:1.15,d:1.1,e:1.2,flow:1.4,willTick:.2,focus:4,will:25,desc:'Darkened frame and pale sigils in canon. Test prerequisite: active Perfect Demon Form.'},
alc:{name:'Abyssal Lightning Cloak',who:'rikito',slot:'cloak',p:1.15,sp:1.2,cs:1.05,flow:.8,focus:2,will:8,desc:'Black-violet lightning coat for speed and physical pressure.'},
lunar:{name:'Full-Powered Lunar Pressure',who:'rikito',slot:'blessing',p:1.08,a:1.08,e:1.1,flow:.3,willTick:.1,focus:2,will:15,spirit:true,desc:'Lunario’s blessing, not a Form. Silver-blue motes over the underlying stack.'}
};
const moves={};
function add(id,name,who,cat,type,s,r,f,a,st,w,extra={}){moves[id]={id,name,who,cat,type,s,r,f,a,st,w,desc:'',...extra};}
add('jab','Quick strike','both','Attacks','physical',6,10,0,0,8,0,{coef:.75,desc:'Cheap pressure; no interruption. Physical startup scales with Agility.'});
add('heavy','Heavy strike','both','Attacks','physical',12,18,0,0,20,0,{coef:1.4,loss:1,desc:'Slower physical hit with Focus pressure.'});
add('barrage','Dragon’s Barrage','akira','Attacks','physical',10,16,1,10,24,0,{coef:1.5,desc:'Multi-strike animation represented by one combined damage event.'});
add('godbreaker','God Breaker','akira','Attacks','physical',12,20,3,45,20,10,{coef:2,divine:true,pierce:.3,desc:'Blue aether-coated strike; ignores 30% of defense rating (test interpretation).'});
add('star','Utopic Star Destroyer','akira','Arts','aether',16,20,3,35,0,0,{power:150,desc:'Go-to golden beam; efficient with Control and Divine Pressure.'});
add('breaker','Star Breaker','akira','Arts','aether',26,27,6,80,0,0,{power:330,loss:2,finisher:true,desc:'Heavy gold beam; forces involuntary Focus loss after retention.'});
add('stardust','True Utopic Stardust Breaker','akira','Arts','aether',34,34,10,155,0,25,{power:650,finisher:true,divine:true,desc:'Late Arc IV finisher. High impact and meaningful commitment.'});
add('nebulus','Nebulus','akira','Utility','aether',10,14,2,35,0,0,{effect:'nebulus',desc:'Prepare stardust for Protos or Supernova. Lasts 80 ticks.'});
add('protos','Protos','akira','Arts','aether',4,14,3,50,0,0,{power:200,requires:'nebulus',desc:'Fast lesser-star attack requiring a prepared Nebulus cloud.'});
add('supernova','Supernova','akira','Arts','aether',30,30,8,130,0,15,{power:480,area:true,requires:'nebulus',desc:'Heavy stellar orb; area impact only partly evadable. This test consumes it as an attack, never also as fuel.'});
add('sunburst','Sunburst · Last resort','akira','Arts','aether',40,50,12,200,0,60,{power:1300,area:true,finisher:true,requires:'photo',fatal:true,desc:'Requires Photoreception. Empties aether and KOs the user at impact, even if evaded. Deliberately sacrificial; may end in a draw.'});
add('deep','Deep Crash','rikito','Attacks','physical',10,15,0,0,17,0,{coef:1.35,desc:'Reliable physical entry.'});
add('rush','Abyssal Ruination','rikito','Attacks','physical',12,19,3,40,24,0,{coef:2.05,loss:1,desc:'Lightning-cloaked rush; fast pressure with a stamina commitment.'});
add('lightning','Black Lightning','rikito','Arts','aether',12,15,2,28,0,0,{power:125,dark:true,desc:'Low-cost dark lightning. Useful when expensive finishers are unsafe.'});
add('cannon','Dark Lightning Cannon','rikito','Arts','aether',18,20,3,38,0,0,{power:170,dark:true,desc:'Go-to ranged pressure.'});
add('abyss','Abyss Breaker','rikito','Arts','aether',26,27,6,85,0,0,{power:340,dark:true,finisher:true,loss:2,desc:'Dense black-violet orb and Focus pressure.'});
add('ruination','Ruination Cannon','rikito','Arts','aether',33,32,9,145,0,20,{power:610,dark:true,finisher:true,desc:'Major beam finisher. Benefits from prepared Midnight and Archaic.'});
add('darkruin','Dark Ruin','rikito','Arts','aether',22,25,5,85,0,20,{power:150,dark:true,area:true,effect:'slow',desc:'Damaging ruin field: +25% new action timings for 24 ticks. Existing commitments are unchanged.'});
add('midnight','Midnight','rikito','Utility','aether',7,10,2,35,0,5,{effect:'midnight',desc:'Next dark attack within 60 ticks gains ×1.30 damage. Consumed on commitment.'});
add('archaic','Archaic','rikito','Utility','aether',9,13,3,55,0,20,{effect:'archaic',desc:'Next finisher within 60 ticks gains ×1.35 damage. Can combine with Midnight.'});
add('guard','Guard','both','Defense','guard',0,14,0,0,10,0,{desc:'Take 40% damage for 18 ticks. A new commitment ends Guard; Ego pressure is separate.'});
add('dodge','Evasive step','both','Defense','dodge',2,14,1,0,22,0,{desc:'Evade one hit for 16 ticks. Area attacks still deal 65% damage.'});
add('shift','Dragon Shift','akira','Defense','dodge',2,12,2,24,0,0,{desc:'Teleport evasion for one incoming hit. Area attacks still partly connect.'});
add('clones','Astra Eidolon Array','akira','Utility','aether',9,14,3,60,0,20,{effect:'clones',desc:'Create two pre-existing clones for 50 ticks. Physical attacks gain 15% per clone; substitution consumes one. Excludes Exponential states.'});
add('substitute','Astral Substitution','akira','Defense','dodge',1,10,1,12,0,5,{requires:'clone',desc:'Consume an existing clone to enable a one-hit evasive swap. Cannot create a clone by itself.'});
add('festival','Dragon Festival','akira','Ego & Spirit','aether',16,22,5,110,0,35,{effect:'seal',divine:true,requires:'signature',desc:'Requires 2 signature familiarity. Cancel an enemy pending Art, then suppress their Arts for 20 ticks. Not an Ego attack.'});
add('regen','Blessed Kiss · Infinite Regenerations','akira','Ego & Spirit','aether',8,18,3,70,0,20,{effect:'regen',desc:'For 40 ticks, restore up to 1.8 HP/tick for 0.7 aether/tick. Costly regeneration, not immortality.'});
add('solarabsorb','Solar Absorption','akira','Ego & Spirit','spirit',18,18,2,0,0,30,{effect:'absorb',spirit:true,desc:'Helios draws 180 aether from sunlight. 60-tick cooldown; unavailable in a sealed arena.'});
add('reflection','Lunar Reflection','rikito','Defense','spirit',4,16,3,60,0,30,{effect:'reflect',spirit:true,desc:'For 20 ticks, halve the first non-area energy Art hit and return 40% of its pre-counter damage. Misc-listed counter; exact Arc IV placement and mechanics are provisional.'});
add('moondrip','Moon Drip','rikito','Ego & Spirit','spirit',14,22,4,0,0,100,{effect:'moondrip',spirit:true,desc:'Once per spar: restore 45% max aether, 30% max stamina and 15% max HP. Canon restoration compressed for this test.'});
add('charge','Charge','both','Utility','charge',12,12,0,0,4,0,{desc:'Gain Flux-based Focus; cannot charge with zero aether or full Focus.'});
add('breath','Catch breath','both','Utility','rest',16,16,0,0,0,0,{desc:'Restore up to 60 stamina. No aether or Will recovery.'});
add('read','Read aether signature','both','Ego & Spirit','ego',8,12,0,0,0,15,{effect:'read',desc:'Experimental control action: gain 2 familiarity and 1 Focus. Supports Akira’s canon signature requirement.'});
add('pressure','Ego pressure · Experimental','both','Ego & Spirit','ego',8,16,2,0,0,35,{effect:'pressure',desc:'Prototype interaction, not a named canon Art: attack Will and Focus retention; does no HP damage or possession.'});
add('center','Recenter · Experimental','both','Ego & Spirit','ego',18,18,0,0,12,0,{effect:'center',desc:'Restore 45 Will; remove slow and shaken. Does not dispel Dragon Festival. Prototype mental-control action.'});
add('brace','Ego brace · Experimental','both','Defense','ego',2,12,0,0,0,20,{effect:'brace',desc:'For 24 ticks, reduce incoming Ego-pressure Will/Focus loss by 70%. No HP shield.'});
add('release','Release all layers','both','Forms','form',0,8,0,0,0,0,{effect:'release',desc:'Return to base and end all ongoing form upkeep. Temporary Arts remain until their duration ends.'});
for(const [id,f] of Object.entries(forms))add(id,f.name,f.who||'both','Forms','form',id==='dp'?4:10,12,f.focus,0,0,f.will,{form:id,desc:f.desc});
for(const id of ['godbreaker','rush','shift','substitute'])moves[id].art=true;
return {keys,people,forms,moves,version:'0.6',war:{akira:['dp','tgou','usr','gem','solar'],rikito:['dp','pdf','ddsr','tdf','alc','lunar']},peak:{akira:['dp','tgou','esr12','solar'],rikito:['dp','pdf','ddsr','tdf','inf','alc','lunar']}};
})();
if(typeof module!=='undefined')module.exports=HighData;
