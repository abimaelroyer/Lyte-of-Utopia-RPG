const ModelForBuild=typeof ArtModel!=='undefined'?ArtModel:require('./art-model.js');
const RulesForDuel=typeof BuildRules!=='undefined'?BuildRules:require('./build-rules.js');
const ParentDuel=typeof HighDuel!=='undefined'?HighDuel:require('./high-engine.js');
class BuildDuel extends ParentDuel{
 constructor(builds,options={}){
  for(const b of Object.values(builds)){const issues=RulesForDuel.errors(b);if(issues.length)throw Error(b.id+': '+issues.join(' '));}
  const data=JSON.parse(JSON.stringify(RulesForDuel.data));data.version='0.8';
  for(const [id,b] of Object.entries(builds))data.people[id].stats=[...b.stats];
  for(const [id,m] of Object.entries(data.moves)){if(RulesForDuel.removed.has(id)){delete data.moves[id];continue;}m.cat=RulesForDuel.category(m);m.w=0;ModelForBuild.prepare(m);}
  for(const f of Object.values(data.forms)){f.will=0;f.willTick=0;}
  super({...options,data,builds:JSON.parse(JSON.stringify(builds)),preset:'base'});
 }
 base(id){const b=super.base(id),build=this.options.builds[id],p=RulesForDuel.pool(build);return {...b,link:RulesForDuel.link(build),spirit:p.spirit,aether:p.native+p.spirit,will:0};}
 available(w){const ids=RulesForDuel.equipped(this.options.builds[w.id]);return Object.values(this.d.moves).filter(m=>ids.includes(m.id));}
 reason(w,m,ignoreReady=false){if(!m||!this.available(w).some(x=>x.id===m.id))return 'Technique not equipped';return super.reason(w,m,ignoreReady);}
 bond(w){return RulesForDuel.perk(this.options.builds[w.id]);}
 chooseAI(w){const legal=k=>!this.reason(w,this.d.moves[k]);const priority=[];if(w.stamina<25)priority.push('breath');if(w.focus<3)priority.push('charge');if(w.aether<this.base(w.id).aether*.4)priority.push('moondrip','solarabsorb');if(!w.layers.length&&w.count<4)priority.push(...this.available(w).filter(m=>m.form).map(m=>m.id));
 const attacks=this.available(w).filter(m=>m.cat==='Attacks');if(attacks.length)priority.push(attacks[w.count%attacks.length].id);priority.push(...attacks.map(m=>m.id),'charge','breath');return priority.find(legal)||'breath';}
 cancelReason(w){const reason=super.cancelReason({...w,will:100});return reason;}
 cancel(id){const w=this.actor(id),reason=this.cancelReason(w);if(reason)return {ok:false,reason};const name=this.d.moves[w.pending.key].name;this.change(w,'focus',-3,'Move Cancel');w.pending=null;w.ready=this.t+6;w.status.guard=this.t+8;w.cooldowns.cancel=this.t+60;this.fx=[];this.note('Move Cancel: '+name+' → short Guard. Costs remain spent.');this.capture('Move Cancel');return {ok:true};}
}
if(typeof module!=='undefined')module.exports=BuildDuel;
