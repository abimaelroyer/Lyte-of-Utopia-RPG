LYTE OF UTOPIA — DUEL SPRITES v0.2

52 PNG frames; 13 four-frame strips. Frame size 128 x 144. Anchor (64,136).
All sprites face right in source files; mirror Rikito horizontally for a duel.
Use nearest-neighbor scaling. No trimming per frame.

Akira: idle, guard, charge, strike, cast, shift, breath.
Rikito: idle, guard, charge, strike, cast, orb. Catch breath currently uses guard.
Frame timings in manifest.json. Generated draft art may retain subtle shape flicker.
No dedicated hit sprite yet; the HTML uses a brief hit flash and damage number.

Source styling: Rikito portrait provided by the author; existing Akira pixel sprites.
Source Arts: Arc I PDF pp. 218–221, 233–236, 248–249.
Gold Utopic beams, gold Star Breaker, yellow Dragon Shift runes; Rikito black/violet lightning and swirling Abyss Breaker orb.
The source constrains color and broad effect; exact pose, timing and pixel VFX geometry are game adaptations.
